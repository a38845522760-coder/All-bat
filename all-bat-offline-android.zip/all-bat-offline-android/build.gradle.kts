plugins {
    id("com.android.application") version "8.7.3" apply false
    // Kotlin 2.2 can read the metadata of newer libraries (LiteRT-LM is published as "latest.release").
    id("org.jetbrains.kotlin.android") version "2.2.20" apply false
}
