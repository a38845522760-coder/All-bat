package com.allbat.offline

private val THINK_BLOCK = Regex("<think>[\\s\\S]*?</think>")

/** Removes the model's hidden reasoning and stop tokens. Second value is true while an unfinished <think> block is open. */
fun cleanModelText(raw: String): Pair<String, Boolean> {
    var s = raw.replace(THINK_BLOCK, "").replace("<|im_end|>", "")
    val open = s.indexOf("<think>")
    var thinking = false
    if (open >= 0) {
        s = s.substring(0, open)
        thinking = true
    }
    return s.trimStart() to thinking
}
