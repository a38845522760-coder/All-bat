package com.allbat.offline

import android.app.ActivityManager
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.StatFs
import java.io.File

/** Downloads and keeps the offline models. The system DownloadManager gives resume, background download and notifications. */
object ModelStore {
    /** Open (Apache-2.0) models converted for LiteRT-LM by the LiteRT community. */
    data class ModelInfo(
        val id: String,
        val title: String,
        val url: String,
        val fileName: String,
        val approxBytes: Long,
        val minValidBytes: Long,
        val note: String
    )

    val LIGHT = ModelInfo(
        id = "qwen3_06b",
        title = "سبک — Qwen3-0.6B",
        url = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm?download=true",
        fileName = "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm",
        approxBytes = 343_000_000L,
        minValidBytes = 200_000_000L,
        note = "حدود ۳۴۰ مگابایت؛ کم‌مصرف و سریع، مناسب رم ۳ تا ۴ گیگابایت. فارسی‌اش ساده‌تر و ضعیف‌تر است."
    )
    val STANDARD = ModelInfo(
        id = "qwen35_08b",
        title = "استاندارد — Qwen3.5-0.8B",
        url = "https://huggingface.co/litert-community/Qwen3.5-0.8B/resolve/main/Qwen3.5-0.8B_int8.litertlm?download=true",
        fileName = "Qwen3.5-0.8B_int8.litertlm",
        approxBytes = 965_000_000L,
        minValidBytes = 400_000_000L,
        note = "حدود ۹۶۵ مگابایت؛ کیفیت و فارسی بهتر، ولی حدود ۱٫۵ تا ۲ گیگابایت رم آزاد می‌خواهد (رم ۶ گیگابایت به بالا بهتر است)."
    )
    val SMALL_PLUS = ModelInfo(
        id = "qwen3_17b",
        title = "سبک‌پلاس — Qwen3-1.7B",
        url = "https://huggingface.co/litert-community/Qwen3-1.7B/resolve/main/Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm?download=true",
        fileName = "Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm",
        approxBytes = 977_000_000L,
        minValidBytes = 800_000_000L,
        note = "حدود ۹۷۷ مگابایت؛ از مدل‌های ۰٫۶ و ۰٫۸ میلیاردی دقیق‌تر و فارسی‌اش بهتر است. رم ۴ گیگابایت به بالا."
    )
    val MEDIUM = ModelInfo(
        id = "gemma4_e2b",
        title = "متوسط — Gemma 4 E2B",
        url = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm?download=true",
        fileName = "gemma-4-E2B-it.litertlm",
        approxBytes = 2_588_147_712L,
        minValidBytes = 2_400_000_000L,
        note = "حدود ۲٫۶ گیگابایت؛ مدل گوگل (Apache-2.0) و در این اندازه یکی از بهترین‌ها برای فارسی و چندزبانه. رم ۶ گیگابایت به بالا."
    )
    val MEDIUM_PLUS = ModelInfo(
        id = "qwen3_4b",
        title = "متوسط‌پلاس — Qwen3-4B",
        url = "https://huggingface.co/litert-community/Qwen3-4B/resolve/main/qwen3_4b_mixed_int4.litertlm?download=true",
        fileName = "qwen3_4b_mixed_int4.litertlm",
        approxBytes = 2_660_000_000L,
        minValidBytes = 2_300_000_000L,
        note = "حدود ۲٫۷ گیگابایت؛ مدل ۴ میلیارد پارامتری با استدلال و کدنویسی بهتر. رم ۸ گیگابایت به بالا؛ روی CPU کندتر است."
    )
    val STRONG = ModelInfo(
        id = "gemma4_e4b",
        title = "قوی — Gemma 4 E4B",
        url = "https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm/resolve/main/gemma-4-E4B-it.litertlm?download=true",
        fileName = "gemma-4-E4B-it.litertlm",
        approxBytes = 3_659_530_240L,
        minValidBytes = 3_400_000_000L,
        note = "حدود ۳٫۷ گیگابایت؛ قوی‌ترین گزینهٔ گوگل برای گوشی، با فارسی و درک مطلب بسیار بهتر. رم ۱۰ گیگابایت به بالا؛ با GPU روشن رم کمتری می‌گیرد."
    )
    val STRONG_PLUS = ModelInfo(
        id = "qwen35_4b",
        title = "قوی‌پلاس — Qwen3.5-4B",
        url = "https://huggingface.co/litert-community/Qwen3.5-4B/resolve/main/Qwen3.5-4B_int8.litertlm?download=true",
        fileName = "Qwen3.5-4B_int8.litertlm",
        approxBytes = 4_100_000_000L,
        minValidBytes = 3_700_000_000L,
        note = "حدود ۴٫۱ گیگابایت؛ نسل جدید Qwen، ویژهٔ گوشی‌های پرچم‌دار با رم ۱۲ گیگابایت به بالا. کند و رم‌خور است."
    )
    val ALL = listOf(LIGHT, STANDARD, SMALL_PLUS, MEDIUM, MEDIUM_PLUS, STRONG, STRONG_PLUS)

    private const val PREFS = "model_store"
    private const val KEY_ACTIVE = "active_model"

    sealed class DownloadState {
        object None : DownloadState()
        data class Running(val done: Long, val total: Long, val paused: Boolean) : DownloadState()
        data class Failed(val reason: Int) : DownloadState()
        object Done : DownloadState()
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun manager(ctx: Context) = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private fun idKey(m: ModelInfo) = "dl_${m.id}"
    private fun failKey(m: ModelInfo) = "fail_${m.id}"

    fun dir(ctx: Context): File =
        (ctx.getExternalFilesDir("models") ?: File(ctx.filesDir, "models")).also { it.mkdirs() }

    fun file(ctx: Context, m: ModelInfo): File = File(dir(ctx), m.fileName)
    private fun partFile(ctx: Context, m: ModelInfo): File = File(dir(ctx), "${m.fileName}.part")

    fun isInstalled(ctx: Context, m: ModelInfo): Boolean = file(ctx, m).let { it.isFile && it.length() > m.minValidBytes }
    fun installedModels(ctx: Context): List<ModelInfo> = ALL.filter { isInstalled(ctx, it) }

    fun totalRamBytes(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.totalMem
    }

    /** totalMem is reported a bit below the nominal size (a "6 GB" phone shows about 5.5 GB), so the limits sit under the round numbers. */
    fun recommended(ctx: Context): ModelInfo {
        val ram = totalRamBytes(ctx)
        return when {
            ram <= 3_700_000_000L -> LIGHT
            ram <= 5_500_000_000L -> SMALL_PLUS
            ram <= 7_500_000_000L -> MEDIUM
            else -> STRONG.takeIf { ram >= 9_500_000_000L } ?: MEDIUM
        }
    }

    /** The model the chat uses: the chosen one if installed, otherwise any installed one, otherwise the recommended one. */
    fun active(ctx: Context): ModelInfo {
        val stored = ALL.firstOrNull { it.id == prefs(ctx).getString(KEY_ACTIVE, null) }
        if (stored != null && isInstalled(ctx, stored)) return stored
        installedModels(ctx).firstOrNull()?.let { return it }
        return stored ?: recommended(ctx)
    }

    fun hasActive(ctx: Context): Boolean = isInstalled(ctx, active(ctx))

    fun setActive(ctx: Context, m: ModelInfo) {
        prefs(ctx).edit().putString(KEY_ACTIVE, m.id).apply()
    }

    fun hasEnoughSpace(ctx: Context, model: ModelInfo): Boolean = try {
        StatFs(dir(ctx).absolutePath).availableBytes > model.approxBytes + 350_000_000L
    } catch (_: Exception) {
        true
    }

    fun start(ctx: Context, model: ModelInfo) {
        cancel(ctx, model)
        prefs(ctx).edit().remove(failKey(model)).apply()
        val part = partFile(ctx, model)
        if (part.exists()) part.delete()
        val request = DownloadManager.Request(Uri.parse(model.url))
            .setTitle("مدل آفلاین All Bat")
            .setDescription(model.title)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .addRequestHeader("User-Agent", "AllBatOffline/1.0")
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
            .setDestinationInExternalFilesDir(ctx, "models", "${model.fileName}.part")
        val id = manager(ctx).enqueue(request)
        prefs(ctx).edit().putLong(idKey(model), id).apply()
    }

    fun cancel(ctx: Context, m: ModelInfo) {
        val id = prefs(ctx).getLong(idKey(m), -1L)
        if (id >= 0) {
            try { manager(ctx).remove(id) } catch (_: Exception) { }
        }
        prefs(ctx).edit().remove(idKey(m)).apply()
        val part = partFile(ctx, m)
        if (part.exists()) part.delete()
    }

    fun delete(ctx: Context, m: ModelInfo) {
        cancel(ctx, m)
        prefs(ctx).edit().remove(failKey(m)).apply()
        val f = file(ctx, m)
        if (f.exists()) f.delete()
    }

    fun state(ctx: Context, m: ModelInfo): DownloadState {
        if (isInstalled(ctx, m)) return DownloadState.Done
        val id = prefs(ctx).getLong(idKey(m), -1L)
        if (id < 0) {
            return if (prefs(ctx).contains(failKey(m))) DownloadState.Failed(prefs(ctx).getInt(failKey(m), 0)) else DownloadState.None
        }
        val cursor = runCatching { manager(ctx).query(DownloadManager.Query().setFilterById(id)) }.getOrNull()
            ?: return DownloadState.None
        return cursor.use { c ->
            if (!c.moveToFirst()) {
                prefs(ctx).edit().remove(idKey(m)).apply()
                return@use DownloadState.None
            }
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    if (finalizeDownload(ctx, m)) DownloadState.Done else failed(ctx, m, -1)
                }
                DownloadManager.STATUS_FAILED -> failed(ctx, m, reason)
                DownloadManager.STATUS_PAUSED -> DownloadState.Running(done, total, true)
                else -> DownloadState.Running(done, total, false)
            }
        }
    }

    private fun failed(ctx: Context, m: ModelInfo, reason: Int): DownloadState {
        cancel(ctx, m)
        prefs(ctx).edit().putInt(failKey(m), reason).apply()
        return DownloadState.Failed(reason)
    }

    private fun finalizeDownload(ctx: Context, m: ModelInfo): Boolean {
        val part = partFile(ctx, m)
        val target = file(ctx, m)
        prefs(ctx).edit().remove(idKey(m)).apply()
        if (!part.exists()) return isInstalled(ctx, m)
        if (part.length() <= m.minValidBytes) {
            part.delete()
            return false
        }
        if (target.exists()) target.delete()
        return part.renameTo(target)
    }
}
