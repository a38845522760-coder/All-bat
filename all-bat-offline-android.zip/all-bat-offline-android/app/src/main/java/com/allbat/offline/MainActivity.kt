package com.allbat.offline

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())

    private val history = mutableListOf<Msg>()
    private var generating = false
    private var modelReady = false
    private var loading = false
    private var loadFailed = false
    private var genJob: Job? = null
    private var pendingSharedText: String? = null

    // palette
    private var night = false
    private var cBg = 0; private var cSurface = 0; private var cText = 0; private var cSub = 0
    private var cAccent = 0; private var cUser = 0; private var cAi = 0; private var cBorder = 0

    // views
    private lateinit var statusPill: TextView
    private lateinit var banner: TextView
    private lateinit var setupPanel: LinearLayout
    private lateinit var setupText: TextView
    private lateinit var setupProgress: ProgressBar
    private lateinit var setupButton: TextView
    private lateinit var setupCancel: TextView
    private lateinit var setupButton2: TextView
    private lateinit var chatScroll: ScrollView
    private lateinit var chatList: LinearLayout
    private lateinit var input: EditText
    private lateinit var sendButton: TextView
    private lateinit var emptyHint: TextView
    private lateinit var modelsPage: LinearLayout
    private lateinit var modelsList: LinearLayout
    private lateinit var modelsRam: TextView

    private class ModelCard(
        val model: ModelStore.ModelInfo,
        val status: TextView,
        val progress: ProgressBar,
        val primary: TextView,
        val secondary: TextView
    )
    private val modelCards = mutableListOf<ModelCard>()

    private val dp: Float get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * dp).toInt()

    private val poll = object : Runnable {
        override fun run() {
            refreshSetup()
            updateStatusPill()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initPalette()
        buildUi()
        history.addAll(ChatStore.load(this))
        history.forEach { addBubble(it.user, it.text) }
        updateEmptyHint()
        handleIncoming(intent)
        refreshSetup()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    override fun onResume() {
        super.onResume()
        handler.post(poll)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        scope.cancel()
        if (isFinishing) LlmEngine.close()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- palette / ui

    private fun initPalette() {
        night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        if (night) {
            cBg = Color.rgb(20, 22, 27); cSurface = Color.rgb(32, 35, 42); cText = Color.rgb(236, 238, 243)
            cSub = Color.rgb(150, 156, 170); cAccent = Color.rgb(143, 143, 255)
            cUser = Color.rgb(58, 60, 140); cAi = Color.rgb(36, 39, 47); cBorder = Color.rgb(52, 56, 66)
        } else {
            cBg = Color.rgb(242, 244, 248); cSurface = Color.WHITE; cText = Color.rgb(24, 27, 32)
            cSub = Color.rgb(104, 112, 126); cAccent = Color.rgb(91, 91, 245)
            cUser = Color.rgb(226, 228, 255); cAi = Color.WHITE; cBorder = Color.rgb(222, 226, 236)
        }
    }

    private fun rounded(color: Int, radiusDp: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
        if (stroke != Color.TRANSPARENT) setStroke(1, stroke)
    }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        textAlignment = View.TEXT_ALIGNMENT_TEXT_START
    }

    private fun buildUi() {
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            fitsSystemWindows = true
        }

        // header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(8), dp(10))
        }
        header.addView(label("All Bat آفلاین", 19f, cText, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        statusPill = label("", 11.5f, cSub).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = rounded(cSurface, 99, cBorder)
        }
        header.addView(statusPill, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(4) })
        val menu = label("⋮", 24f, cText).apply {
            gravity = Gravity.CENTER
            contentDescription = "منو"
            isClickable = true
            setOnClickListener { showMenu(it) }
        }
        header.addView(menu, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(header)

        banner = label("", 12.5f, cSub).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(6), dp(16), dp(6))
            visibility = View.GONE
        }
        root.addView(banner)

        val body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // chat
        chatList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
        }
        chatScroll = ScrollView(this).apply {
            isFillViewport = true
            addView(chatList, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        body.addView(chatScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        emptyHint = label("بدون اینترنت هم جواب می‌دهم.\nیک سؤال بنویس؛ مدل روی خود گوشی اجرا می‌شود.", 14.5f, cSub).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        body.addView(emptyHint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // setup panel (model download)
        setupPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(28), dp(24), dp(28))
            background = rounded(cSurface, 22, cBorder)
            visibility = View.GONE
        }
        setupPanel.addView(label("نصب مدل آفلاین", 18f, cText, true))
        setupText = label("", 14f, cSub).apply {
            setLineSpacing(dp(4).toFloat(), 1f)
            setPadding(0, dp(10), 0, dp(14))
        }
        setupPanel.addView(setupText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setupProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            visibility = View.GONE
        }
        setupPanel.addView(setupProgress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)).apply { bottomMargin = dp(14) })
        setupButton = label("", 15f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            background = rounded(cAccent, 99)
            isClickable = true
        }
        setupPanel.addView(setupButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        setupButton2 = label("", 14.5f, cAccent, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            background = rounded(cSurface, 99, cAccent)
            isClickable = true
        }
        setupPanel.addView(setupButton2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) })
        setupCancel = label("لغو دانلود", 13.5f, cSub).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            isClickable = true
            visibility = View.GONE
            setOnClickListener { cancelAllDownloads(); refreshSetup() }
        }
        setupPanel.addView(setupCancel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        body.addView(setupPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply {
            marginStart = dp(20); marginEnd = dp(20)
        })

        // composer
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(10), dp(6), dp(10), dp(10))
        }
        input = EditText(this).apply {
            hint = "پیام بنویس…"
            setHintTextColor(cSub)
            setTextColor(cText)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            maxLines = 5
            minHeight = dp(48)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_TEXT_START
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = rounded(cSurface, 26, cBorder)
        }
        composer.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sendButton = label("➤", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            background = rounded(cAccent, 99)
            isClickable = true
            setOnClickListener { onSendClicked() }
            contentDescription = "ارسال"
        }
        composer.addView(sendButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        root.addView(composer)

        // models / downloads page (covers the whole screen)
        modelsPage = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
            visibility = View.GONE
            isClickable = true
        }
        val pageHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(10), dp(16), dp(10))
        }
        val back = label("›", 30f, cText).apply {
            gravity = Gravity.CENTER
            contentDescription = "بازگشت"
            isClickable = true
            setOnClickListener { hideModelsPage() }
        }
        pageHeader.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        pageHeader.addView(label("مدل‌ها و دانلود", 19f, cText, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        modelsPage.addView(pageHeader)
        modelsList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(4), dp(14), dp(20))
        }
        modelsRam = label("", 13f, cSub).apply { setPadding(dp(4), 0, dp(4), dp(10)) }
        modelsList.addView(modelsRam)
        ModelStore.ALL.forEach { modelsList.addView(buildModelCard(it), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) }) }
        modelsPage.addView(ScrollView(this).apply { addView(modelsList) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(modelsPage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.layoutDirection = View.LAYOUT_DIRECTION_RTL
        modelsPage.layoutDirection = View.LAYOUT_DIRECTION_RTL
        modelsPage.fitsSystemWindows = true
        setContentView(frame)
        updateComposer()
    }

    private fun buildModelCard(model: ModelStore.ModelInfo): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(cSurface, 18, cBorder)
        }
        card.addView(label(model.title, 16.5f, cText, true))
        card.addView(label(model.note, 13f, cSub).apply { setPadding(0, dp(4), 0, dp(8)); setLineSpacing(dp(3).toFloat(), 1f) })
        val status = label("", 13.5f, cText)
        card.addView(status)
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            visibility = View.GONE
        }
        card.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(8) })
        val primary = label("", 14.5f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            background = rounded(cAccent, 99)
            isClickable = true
        }
        card.addView(primary, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(12) })
        val secondary = label("", 13.5f, cSub).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            isClickable = true
            visibility = View.GONE
        }
        card.addView(secondary, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        modelCards.add(ModelCard(model, status, progress, primary, secondary))
        return card
    }

    private fun showModelsPage() {
        modelsPage.visibility = View.VISIBLE
        refreshModelsPage(ModelStore.ALL.associateWith { ModelStore.state(this, it) })
    }

    private fun hideModelsPage() {
        modelsPage.visibility = View.GONE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (modelsPage.visibility == View.VISIBLE) hideModelsPage() else super.onBackPressed()
    }

    private fun refreshModelsPage(states: Map<ModelStore.ModelInfo, ModelStore.DownloadState>) {
        val ramGb = ModelStore.totalRamBytes(this) / 1_000_000_000.0
        val rec = ModelStore.recommended(this)
        modelsRam.text = "رم این گوشی: حدود ${"%.1f".format(ramGb)} گیگابایت — پیشنهاد: ${rec.title}\nدانلود در پس‌زمینه هم ادامه پیدا می‌کند و در نوار اعلان‌ها هم دیده می‌شود."
        val active = ModelStore.active(this)
        for (c in modelCards) {
            val m = c.model
            val state = states[m] ?: ModelStore.DownloadState.None
            c.progress.visibility = View.GONE
            c.secondary.visibility = View.GONE
            c.primary.alpha = 1f
            c.primary.background = rounded(cAccent, 99)
            when (state) {
                is ModelStore.DownloadState.Running -> {
                    val total = if (state.total > 0) state.total else m.approxBytes
                    c.progress.visibility = View.VISIBLE
                    c.progress.progress = ((state.done * 1000L) / total).toInt().coerceIn(0, 1000)
                    c.status.text = (if (state.paused) "متوقف (منتظر اینترنت): " else "در حال دانلود: ") +
                        "${mb(state.done)} از ${mb(total)} مگابایت (${percent(state.done, total)}٪)"
                    c.primary.text = "لغو دانلود"
                    c.primary.background = rounded(cSub, 99)
                    c.primary.setOnClickListener { ModelStore.cancel(this, m); refreshSetup() }
                }
                is ModelStore.DownloadState.Done -> {
                    val isActive = active.id == m.id
                    c.status.text = if (isActive) "نصب شده ✓ — در حال استفاده" else "نصب شده ✓"
                    if (isActive) {
                        c.primary.text = "در حال استفاده"
                        c.primary.alpha = 0.5f
                        c.primary.setOnClickListener(null)
                    } else {
                        c.primary.text = "استفاده از این مدل"
                        c.primary.setOnClickListener { useModel(m) }
                    }
                    c.secondary.visibility = View.VISIBLE
                    c.secondary.text = "حذف از گوشی"
                    c.secondary.setOnClickListener { confirmDelete(m) }
                }
                is ModelStore.DownloadState.Failed -> {
                    c.status.text = "دانلود ناموفق بود (کد ${state.reason})"
                    c.primary.text = "تلاش دوباره"
                    c.primary.setOnClickListener { startDownload(m) }
                }
                else -> {
                    c.status.text = "نصب نشده — ${mb(m.approxBytes)} مگابایت"
                    c.primary.text = "دانلود"
                    c.primary.setOnClickListener { startDownload(m) }
                }
            }
        }
    }

    private fun startDownload(model: ModelStore.ModelInfo) {
        if (!ModelStore.hasEnoughSpace(this, model)) {
            Toast.makeText(this, "فضای خالی کافی نیست (حدود ${(model.approxBytes + 350_000_000L) / 1_000_000L} مگابایت لازم است)", Toast.LENGTH_LONG).show()
            return
        }
        loadFailed = false
        ModelStore.start(this, model)
        refreshSetup()
    }

    private fun useModel(model: ModelStore.ModelInfo) {
        if (generating) {
            Toast.makeText(this, "اول صبر کن پاسخ تمام شود", Toast.LENGTH_SHORT).show()
            return
        }
        ModelStore.setActive(this, model)
        LlmEngine.close()
        modelReady = false
        loadFailed = false
        hideModelsPage()
        refreshSetup()
    }

    private fun addBubble(user: Boolean, text: String): TextView {
        val tv = label(text, 15.5f, cText).apply {
            setTextIsSelectable(true)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(if (user) cUser else cAi, 18, if (user) Color.TRANSPARENT else cBorder)
            maxWidth = (resources.displayMetrics.widthPixels * 0.86f).toInt()
        }
        chatList.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (user) Gravity.START else Gravity.END
            topMargin = dp(6)
        })
        updateEmptyHint()
        scrollDown()
        return tv
    }

    private fun updateEmptyHint() {
        emptyHint.visibility = if (history.isEmpty() && chatList.childCount == 0 && modelReady) View.VISIBLE else View.GONE
    }

    private fun scrollDown() {
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun updateStatusPill() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val online = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        statusPill.text = if (online) "آنلاین" else "آفلاین"
        statusPill.setTextColor(if (online) cSub else cAccent)
    }

    private fun updateComposer() {
        val canType = modelReady
        input.isEnabled = canType && !generating
        input.hint = when {
            loading -> "در حال بارگذاری مدل…"
            !ModelStore.hasActive(this) -> "ابتدا مدل را نصب کن"
            else -> "پیام بنویس…"
        }
        sendButton.text = if (generating) "■" else "➤"
        sendButton.alpha = if (canType) 1f else 0.4f
        sendButton.contentDescription = if (generating) "توقف" else "ارسال"
    }

    // ---------------------------------------------------------------- menu

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, "گفت‌وگوی جدید")
        val gpu = prefs().getBoolean("gpu", false)
        popup.menu.add(0, 2, 1, if (gpu) "شتاب GPU: روشن (آزمایشی)" else "شتاب GPU: خاموش (آزمایشی)")
        popup.menu.add(0, 3, 2, "مدل‌ها و دانلود")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> newChat()
                2 -> toggleGpu()
                3 -> showModelsPage()
            }
            true
        }
        popup.show()
    }

    private fun prefs() = getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun newChat() {
        if (generating) return
        history.clear()
        ChatStore.clear(this)
        chatList.removeAllViews()
        updateEmptyHint()
        if (modelReady) scope.launch(Dispatchers.Default) { runCatching { LlmEngine.startConversation(history) } }
    }

    private fun toggleGpu() {
        if (generating) return
        val newValue = !prefs().getBoolean("gpu", false)
        prefs().edit().putBoolean("gpu", newValue).apply()
        Toast.makeText(this, if (newValue) "GPU روشن شد؛ مدل دوباره بارگذاری می‌شود" else "GPU خاموش شد؛ مدل دوباره بارگذاری می‌شود", Toast.LENGTH_SHORT).show()
        LlmEngine.close()
        modelReady = false
        loadFailed = false
        refreshSetup()
    }

    private fun confirmDelete(model: ModelStore.ModelInfo) {
        AlertDialog.Builder(this)
            .setTitle("حذف ${model.title}؟")
            .setMessage("فایل مدل (${model.approxBytes / 1_000_000L} مگابایت) پاک می‌شود. هر وقت خواستی دوباره دانلود می‌کنی.")
            .setPositiveButton("حذف") { _, _ ->
                if (ModelStore.active(this).id == model.id) {
                    genJob?.cancel()
                    LlmEngine.close()
                    modelReady = false
                }
                loadFailed = false
                ModelStore.delete(this, model)
                refreshSetup()
            }
            .setNegativeButton("نه", null)
            .show()
    }

    private fun cancelAllDownloads() {
        ModelStore.ALL.forEach { if (ModelStore.state(this, it) is ModelStore.DownloadState.Running) ModelStore.cancel(this, it) }
    }

    // ---------------------------------------------------------------- model setup / load

    private fun mb(bytes: Long) = (bytes / 1_000_000L).toString()

    private fun refreshSetup() {
        // Query every model first: this also finishes a completed download (renames the .part file).
        val states = ModelStore.ALL.associateWith { ModelStore.state(this, it) }
        if (ModelStore.hasActive(this)) {
            setupPanel.visibility = View.GONE
            if (!modelReady && !loading && !loadFailed) loadModel()
        } else {
            val running = states.entries.firstOrNull { it.value is ModelStore.DownloadState.Running }
            val failed = states.entries.firstOrNull { it.value is ModelStore.DownloadState.Failed }
            if (running != null) {
                val state = running.value as ModelStore.DownloadState.Running
                setupPanel.visibility = View.VISIBLE
                setupProgress.visibility = View.VISIBLE
                setupButton2.visibility = View.GONE
                val total = if (state.total > 0) state.total else running.key.approxBytes
                setupProgress.progress = ((state.done * 1000L) / total).toInt().coerceIn(0, 1000)
                setupText.text = (if (state.paused) "دانلود متوقف شد (منتظر اینترنت)…\n" else "در حال دانلود ${running.key.title}…\n") +
                    "${mb(state.done)} از ${mb(total)} مگابایت (${percent(state.done, total)}٪)\nمی‌توانی از برنامه بیرون بروی؛ دانلود ادامه پیدا می‌کند."
                setupButton.text = "در حال دانلود…"
                setupButton.alpha = 0.5f
                setupButton.setOnClickListener(null)
                setupCancel.visibility = View.VISIBLE
            } else {
                val reason = (failed?.value as? ModelStore.DownloadState.Failed)?.reason
                showSetupIdle(reason?.let { "دانلود ناموفق بود (کد $it). اینترنت را بررسی کن و دوباره امتحان کن." })
            }
        }
        modelReady = modelReady && LlmEngine.isLoaded
        updateComposer()
        if (modelsPage.visibility == View.VISIBLE) refreshModelsPage(states)
    }

    private fun percent(done: Long, total: Long): Int = if (total <= 0) 0 else ((done * 100L) / total).toInt().coerceIn(0, 100)

    private fun showSetupIdle(error: String?) {
        setupPanel.visibility = View.VISIBLE
        setupProgress.visibility = View.GONE
        setupCancel.visibility = View.GONE
        val recommended = ModelStore.recommended(this)
        val ramGb = ModelStore.totalRamBytes(this) / 1_000_000_000.0
        setupText.text = (error?.let { "$it\n\n" } ?: "") +
            "برای پاسخ‌دادن بدون اینترنت، یک مدل هوش مصنوعی متن‌باز (مجوز Apache-2.0) باید یک بار روی گوشی نصب شود؛ بهتر است با Wi‑Fi دانلود کنی.\n\n" +
            "رم این گوشی: حدود ${"%.1f".format(ramGb)} گیگابایت\n\n" +
            "پیشنهاد برای این گوشی: ${recommended.title}\n${recommended.note}\n\n" +
            "مدل‌های سبک‌تر و قوی‌تر هم هست؛ دکمهٔ پایین را بزن."
        bindModelButton(setupButton, recommended, "دانلود ${recommended.title} (پیشنهادی)")
        setupButton2.text = "مدل‌های دیگر (سبک تا قوی)"
        setupButton2.alpha = 1f
        setupButton2.setOnClickListener { showModelsPage() }
        setupButton2.visibility = View.VISIBLE
    }

    private fun bindModelButton(button: TextView, model: ModelStore.ModelInfo, text: String) {
        button.text = text
        button.alpha = 1f
        button.setOnClickListener { startDownload(model) }
    }

    private fun loadModel() {
        loading = true
        loadFailed = false
        banner.text = "در حال بارگذاری مدل روی گوشی… (چند ثانیه)"
        banner.visibility = View.VISIBLE
        updateComposer()
        val p = prefs()
        // If the previous GPU start crashed the app, fall back to the CPU automatically.
        var useGpu = p.getBoolean("gpu", false)
        if (useGpu && p.getBoolean("gpu_loading", false)) {
            useGpu = false
            p.edit().putBoolean("gpu", false).putBoolean("gpu_loading", false).apply()
            Toast.makeText(this, "GPU روی این گوشی پایدار نبود؛ با CPU ادامه می‌دهم", Toast.LENGTH_LONG).show()
        }
        if (useGpu) p.edit().putBoolean("gpu_loading", true).commit()
        scope.launch {
            try {
                LlmEngine.load(this@MainActivity, useGpu)
                withContext(Dispatchers.Default) { LlmEngine.startConversation(history) }
                modelReady = true
                banner.visibility = View.GONE
                updateEmptyHint()
                pendingSharedText?.let { text ->
                    pendingSharedText = null
                    input.setText("")
                    submit(text)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                loadFailed = true
                banner.text = "بارگذاری مدل ناموفق بود: ${e.message ?: e.javaClass.simpleName}\nبرای تلاش دوباره همین‌جا را لمس کن، یا از منو مدل را حذف و دوباره نصب کن."
                banner.setOnClickListener { loadFailed = false; banner.setOnClickListener(null); refreshSetup() }
            } finally {
                p.edit().putBoolean("gpu_loading", false).apply()
                loading = false
                updateComposer()
            }
        }
    }

    // ---------------------------------------------------------------- chat

    private fun handleIncoming(intent: Intent?) {
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT)?.trim()
        if (text.isNullOrEmpty()) return
        intent?.removeExtra(Intent.EXTRA_TEXT)
        if (modelReady && !generating) submit(text) else {
            pendingSharedText = text
            input.setText(text)
        }
    }

    private fun onSendClicked() {
        if (generating) { stopGeneration(); return }
        if (!modelReady) return
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        submit(text)
    }

    private fun stopGeneration() {
        genJob?.cancel()
    }

    private fun clean(raw: String): Pair<String, Boolean> = cleanModelText(raw)

    private fun render(view: TextView, raw: String, streaming: Boolean) {
        val (text, thinking) = clean(raw)
        view.text = when {
            text.isNotBlank() -> text
            streaming && thinking -> "در حال فکر کردن…"
            streaming -> "…"
            else -> ""
        }
    }

    private fun submit(text: String) {
        if (generating || !modelReady) return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        history.add(Msg(true, text))
        addBubble(true, text)
        val aiView = addBubble(false, "…")
        generating = true
        updateComposer()
        genJob = scope.launch {
            val sb = StringBuilder()
            var cancelled = false
            var failure: Throwable? = null
            try {
                LlmEngine.send(text).collect { piece ->
                    sb.append(piece)
                    render(aiView, sb.toString(), true)
                    scrollDown()
                }
            } catch (e: CancellationException) {
                cancelled = true
            } catch (e: Throwable) {
                failure = e
            }
            var answer = clean(sb.toString()).first.trim()
            if (failure != null) {
                val note = "⚠️ خطا در تولید پاسخ: ${failure.message ?: failure.javaClass.simpleName}"
                answer = if (answer.isEmpty()) note else "$answer\n\n$note"
            }
            aiView.text = answer.ifEmpty { if (cancelled) "(متوقف شد)" else "" }
            if (answer.isNotEmpty() && failure == null) history.add(Msg(false, answer))
            ChatStore.save(this@MainActivity, history)
            if (cancelled || failure != null) {
                // A stopped or failed answer leaves the native conversation in an unknown state: rebuild it from history.
                withContext(NonCancellable + Dispatchers.Default) { runCatching { LlmEngine.startConversation(history) } }
            }
            generating = false
            updateComposer()
        }
    }
}
