package com.allbat.offline

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Messenger
import android.os.Process
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Lets the main All Bat app ask the offline model a question and receive the answer as it is being written.
 *
 * Protocol (Messenger, all payloads are Bundles with string keys):
 *   client -> MSG_ASK    { id, text }            replyTo = the client's Messenger
 *   client -> MSG_CANCEL { id }
 *   service -> MSG_STATUS  { id, status }        "loading" while the model is being loaded
 *   service -> MSG_PARTIAL { id, text }          the full answer so far
 *   service -> MSG_DONE    { id, text }          the final answer
 *   service -> MSG_ERROR   { id, code, error }   code: no_model | forbidden | empty | failed
 */
class AskService : Service() {
    companion object {
        const val ALLOWED_CALLER = "com.allbat.assistant"
        const val MSG_ASK = 1
        const val MSG_PARTIAL = 2
        const val MSG_DONE = 3
        const val MSG_ERROR = 4
        const val MSG_CANCEL = 5
        const val MSG_STATUS = 6
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val jobs = mutableMapOf<String, Job>()
    private lateinit var messenger: Messenger

    override fun onCreate() {
        super.onCreate()
        messenger = Messenger(Handler(Looper.getMainLooper()) { msg -> handle(msg); true })
    }

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    override fun onUnbind(intent: Intent?): Boolean {
        jobs.values.forEach { it.cancel() }
        jobs.clear()
        return false
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun callerAllowed(uid: Int): Boolean {
        if (uid == Process.myUid()) return true
        if (packageManager.getPackagesForUid(uid)?.contains(ALLOWED_CALLER) != true) return false
        // The name matches; now make sure it is the real app by its signing certificate.
        return PeerVerifier.matches(this, ALLOWED_CALLER, BuildConfig.MAIN_CERT_SHA256)
    }

    private fun handle(msg: android.os.Message) {
        val reply = msg.replyTo
        val data = msg.data
        val id = data.getString("id") ?: ""
        when (msg.what) {
            MSG_ASK -> {
                if (reply == null) return
                if (!callerAllowed(msg.sendingUid)) {
                    send(reply, MSG_ERROR, id, code = "forbidden", error = "این برنامه اجازهٔ استفاده از مدل آفلاین را ندارد")
                    return
                }
                val text = (data.getString("text") ?: "").trim().take(4000)
                if (text.isEmpty()) {
                    send(reply, MSG_ERROR, id, code = "empty", error = "سؤال خالی است")
                    return
                }
                if (!ModelStore.hasActive(this)) {
                    send(reply, MSG_ERROR, id, code = "no_model", error = "مدل آفلاین هنوز نصب نشده است")
                    return
                }
                jobs[id]?.cancel()
                jobs[id] = scope.launch { answer(reply, id, text) }
            }
            MSG_CANCEL -> jobs.remove(id)?.cancel()
        }
    }

    private suspend fun answer(reply: Messenger, id: String, text: String) {
        val acc = StringBuilder()
        try {
            send(reply, MSG_STATUS, id, status = "loading")
            LlmEngine.ask(applicationContext, text).collect { piece ->
                acc.append(piece)
                send(reply, MSG_PARTIAL, id, text = cleanModelText(acc.toString()).first)
            }
            send(reply, MSG_DONE, id, text = cleanModelText(acc.toString()).first.trim())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            send(reply, MSG_ERROR, id, code = "failed", error = e.message ?: e.javaClass.simpleName)
        } finally {
            jobs.remove(id)
        }
    }

    private fun send(
        to: Messenger, what: Int, id: String,
        text: String? = null, status: String? = null, code: String? = null, error: String? = null
    ) {
        val m = android.os.Message.obtain(null, what)
        m.data = Bundle().apply {
            putString("id", id)
            text?.let { putString("text", it) }
            status?.let { putString("status", it) }
            code?.let { putString("code", it) }
            error?.let { putString("error", it) }
        }
        try { to.send(m) } catch (_: Exception) { }
    }
}
