package com.allbat.offline

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** One engine and one conversation for the whole process. */
object LlmEngine {
    private const val SYSTEM_PROMPT =
        "تو «دستیار آفلاین All Bat» هستی و روی خود گوشی کاربر، بدون اینترنت اجرا می‌شوی. " +
            "به فارسی روان و کوتاه پاسخ بده، مگر اینکه کاربر زبان دیگری بخواهد. " +
            "اگر چیزی را نمی‌دانی یا به اینترنت نیاز دارد (خبر، قیمت، آب‌وهوا، رویداد روز)، صریح بگو که آفلاین هستی و نمی‌دانی؛ حدس نزن."

    private val mutex = Mutex()
    private var engine: Engine? = null
    private var conversation: Conversation? = null

    val isLoaded: Boolean get() = engine != null

    suspend fun load(ctx: Context, useGpu: Boolean) {
        mutex.withLock {
            if (engine != null) return
            val appContext = ctx.applicationContext
            withContext(Dispatchers.Default) {
                val config = EngineConfig(
                    modelPath = ModelStore.file(appContext, ModelStore.active(appContext)).absolutePath,
                    backend = if (useGpu) Backend.GPU() else Backend.CPU(),
                    cacheDir = appContext.cacheDir.path
                )
                val e = Engine(config)
                e.initialize()
                engine = e
            }
        }
    }

    /** Starts a fresh conversation, optionally continuing from earlier messages. */
    fun startConversation(history: List<Msg>) {
        val e = engine ?: return
        try { conversation?.close() } catch (_: Exception) { }
        conversation = null
        // The template expects user/model turns in order: start with a user turn and end with a model turn.
        val past = history.filter { it.text.isNotBlank() }.takeLast(8).toMutableList()
        while (past.isNotEmpty() && !past.first().user) past.removeAt(0)
        while (past.isNotEmpty() && past.last().user) past.removeAt(past.lastIndex)
        val config = ConversationConfig(
            systemInstruction = Contents.of(SYSTEM_PROMPT),
            initialMessages = past.map { if (it.user) Message.user(it.text) else Message.model(it.text) },
            samplerConfig = SamplerConfig(topK = 10, topP = 0.95, temperature = 0.8)
        )
        conversation = try {
            e.createConversation(config)
        } catch (_: Exception) {
            // If the saved history cannot be replayed, continue with an empty conversation.
            e.createConversation(ConversationConfig(systemInstruction = Contents.of(SYSTEM_PROMPT)))
        }
    }

    /** Streams the answer in small pieces. */
    fun send(text: String): Flow<String> {
        val c = conversation ?: throw IllegalStateException("گفت‌وگو آماده نیست")
        return c.sendMessageAsync(text, extraContext = mapOf("enable_thinking" to false)).map { it.toString() }
    }

    fun close() {
        try { conversation?.close() } catch (_: Exception) { }
        try { engine?.close() } catch (_: Exception) { }
        conversation = null
        engine = null
    }
}
