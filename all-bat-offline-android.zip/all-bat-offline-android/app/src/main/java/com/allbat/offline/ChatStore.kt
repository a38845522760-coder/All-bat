package com.allbat.offline

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Msg(val user: Boolean, val text: String)

/** Keeps the last messages on disk so the chat survives the app being closed. */
object ChatStore {
    private const val MAX_MESSAGES = 60

    private fun file(ctx: Context) = File(ctx.filesDir, "chat.json")

    fun load(ctx: Context): MutableList<Msg> {
        val out = mutableListOf<Msg>()
        try {
            val f = file(ctx)
            if (!f.isFile) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Msg(o.optBoolean("u"), o.optString("t")))
            }
        } catch (_: Exception) {
            out.clear()
        }
        return out
    }

    fun save(ctx: Context, history: List<Msg>) {
        try {
            val arr = JSONArray()
            history.takeLast(MAX_MESSAGES).forEach { arr.put(JSONObject().put("u", it.user).put("t", it.text)) }
            val tmp = File(ctx.filesDir, "chat.json.tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(file(ctx))
        } catch (_: Exception) {
        }
    }

    fun clear(ctx: Context) {
        try { file(ctx).delete() } catch (_: Exception) { }
    }
}
