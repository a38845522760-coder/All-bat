import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.allbat.offline"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.allbat.offline"
        minSdk = 27
        targetSdk = 34
        // CI builds always get a higher versionCode than the previous one, so every build can update the last.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()?.let { 100 + it }) ?: 1
        versionName = "1.0.0"
        // The 0.8B model needs a 64-bit phone; this also keeps the APK small.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // One fixed signing key for every build: Android only allows an update over an installed app when
    // the signature matches. The key can be replaced with GitHub secrets (see build-apk.yml); keep a
    // backup of whichever key you use, because a different key can never update an installed app.
    signingConfigs {
        create("update") {
            storeFile = file(System.getenv("ALLBAT_KEYSTORE_FILE") ?: "keystore/allbat-offline-update.p12")
            storeType = "pkcs12"
            storePassword = System.getenv("ALLBAT_KEYSTORE_PASSWORD") ?: "JB28DemjVFyOfhvbkvxH"
            keyAlias = System.getenv("ALLBAT_KEY_ALIAS") ?: "allbatoffline"
            keyPassword = System.getenv("ALLBAT_KEY_PASSWORD") ?: (System.getenv("ALLBAT_KEYSTORE_PASSWORD") ?: "JB28DemjVFyOfhvbkvxH")
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("update") }
        getByName("release") { signingConfig = signingConfigs.getByName("update") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources {
            excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        freeCompilerArgs.add("-Xskip-metadata-version-check")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    // Google's open-source on-device LLM runtime (Apache-2.0). Runs .litertlm models fully offline.
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")
}
