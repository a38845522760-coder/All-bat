import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Signing secrets never live in the repository. They come from environment variables (GitHub Secrets)
// or from a git-ignored keystore.properties file (storeFile, storePassword, keyAlias, keyPassword).
val keystoreProps = java.util.Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.isFile) f.inputStream().use { load(it) }
}
fun signingValue(env: String, prop: String): String? =
    System.getenv(env)?.takeIf { it.isNotBlank() } ?: keystoreProps.getProperty(prop)?.takeIf { it.isNotBlank() }
val ksFile = file(System.getenv("ALLBAT_KEYSTORE_FILE")?.takeIf { it.isNotBlank() } ?: keystoreProps.getProperty("storeFile") ?: "keystore/allbat-offline-update.p12")
val ksPassword = signingValue("ALLBAT_KEYSTORE_PASSWORD", "storePassword")
val haveSigning = ksPassword != null && ksFile.isFile
// SHA-256 of the main app's signing certificate (hex, no colons). AskService only answers an app signed with it.
val mainCertPin = (System.getenv("ALLBAT_MAIN_CERT_SHA256")?.takeIf { it.isNotBlank() }
    ?: "131a508097ca6256e998b1b14122a8fea2e1e99d1e56a3bfa42d2f81bcd3bc98").replace(":", "").lowercase()

android {
    namespace = "com.allbat.offline"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.allbat.offline"
        minSdk = 27
        targetSdk = 34
        // CI builds always get a higher versionCode than the previous one, so every build can update the last.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()?.let { 100 + it }) ?: 1
        versionName = "1.1.1"
        // The 0.8B model needs a 64-bit phone; this also keeps the APK small.
        ndk { abiFilters += listOf("arm64-v8a") }
        buildConfigField("String", "MAIN_CERT_SHA256", "\"$mainCertPin\"")
    }

    buildFeatures {
        buildConfig = true
    }

    // One fixed signing key for every release build: Android only allows an update over an installed app
    // when the signature matches. Keep a backup of the key. The key and its password must NOT be committed.
    signingConfigs {
        if (haveSigning) {
            create("update") {
                storeFile = ksFile
                storeType = "pkcs12"
                storePassword = ksPassword
                keyAlias = signingValue("ALLBAT_KEY_ALIAS", "keyAlias") ?: "allbatoffline"
                keyPassword = signingValue("ALLBAT_KEY_PASSWORD", "keyPassword") ?: ksPassword
            }
        }
    }

    buildTypes {
        getByName("release") {
            // Never ship a debuggable build.
            isDebuggable = false
            isMinifyEnabled = false
            if (haveSigning) signingConfig = signingConfigs.getByName("update")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources {
            excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        freeCompilerArgs.add("-Xskip-metadata-version-check")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    // Google's open-source on-device LLM runtime (Apache-2.0). Runs .litertlm models fully offline.
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")
}
