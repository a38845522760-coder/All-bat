/* fb-widget.js: اتصال دکمه‌های 👍/👎 مینی‌اپ به سرور */
(function(){
"use strict";
if(window.__fbWidget)return;window.__fbWidget=1;
var KEY="baleMiniFbV1";
var REASONS=[["wrong","❌ اشتباه بود"],["irrelevant","🎯 بی‌ربط بود"],["incomplete","✂️ ناقص بود"],["format","🧾 قالب/فایل خراب بود"],["tone","🗣 زبان یا لحن بد بود"],["unsafe","⚠️ نامناسب بود"],["other","💬 مورد دیگر"]];
function ls(){try{return window.localStorage}catch(e){return null}}
function readMap(){try{return JSON.parse((ls()&&ls().getItem(KEY))||"{}")||{}}catch(e){return {}}}
var prev=readMap();
function mapVote(v){
  if(!v)return "none";
  var s=String(v).toLowerCase();
  if(/down|dis|bad|neg|-1|👎/.test(s))return "down";
  return "up";
}
function chatId(){try{return (typeof state!=="undefined"&&state&&state.cid)||""}catch(e){return ""}}
function localMsg(id){
  try{var s=state.sessions[state.cid],ms=(s&&s.messages)||[];
    for(var i=0;i<ms.length;i++){if(ms[i].id===id){var p="";for(var j=i-1;j>=0;j--){if(ms[j].role==="user"){p=ms[j].text||"";break}}return {text:String(ms[i].text||"").slice(0,3500),prompt:String(p).slice(0,1500)}}}}catch(e){}
  return {text:"",prompt:""};
}
function headers(){
  var h={"Content-Type":"application/json"};
  try{var c=ls().getItem("baleMiniAppClientId");if(c)h["X-Mini-App-Client-ID"]=c;
      var o=ls().getItem("baleMiniAppWorkspaceOverride");if(o)h["X-Mini-App-Workspace-ID"]=o;}catch(e){}
  try{var i=window.Bale&&window.Bale.WebApp&&window.Bale.WebApp.initData;if(i)h["X-Bale-Init-Data"]=String(i)}catch(e){}
  return h;
}
function base(){try{return (typeof API_BASE!=="undefined"&&API_BASE)||""}catch(e){return ""}}
function say(t){try{if(typeof toast==="function")toast(t)}catch(e){}}
async function post(path,body,retry){
  try{
    var r=await fetch(base()+path,{method:"POST",headers:headers(),body:JSON.stringify(body)});
    var j={};try{j=await r.json()}catch(e){}
    if(j&&j.ok===false&&j.error)say(j.error);
    return j;
  }catch(e){
    if(retry!==false){await new Promise(function(ok){setTimeout(ok,3000)});return post(path,body,false)}
  }
}
function send(id,vote,extra){
  var body={msg_id:id,vote:vote,chat_id:chatId()};
  var m=localMsg(id);body.text=m.text;body.prompt=m.prompt;
  if(extra){for(var k in extra)body[k]=extra[k]}
  return post("/api/feedback",body);
}
function el(tag,css,text){var e=document.createElement(tag);if(css)e.style.cssText=css;if(text!=null)e.textContent=text;return e}
function closeSheet(){var s=document.getElementById("fbSheet");if(s&&s.parentNode)s.parentNode.removeChild(s)}
function sheet(id){
  closeSheet();
  var chosen="other";
  var wrap=el("div","position:fixed;inset:0;z-index:99999;display:flex;align-items:flex-end;justify-content:center;background:rgba(0,0,0,.35);direction:rtl");
  wrap.id="fbSheet";
  var card=el("div","width:100%;max-width:560px;background:var(--s1,#fff);color:var(--tx,#111);border-radius:24px 24px 0 0;padding:16px 16px calc(16px + env(safe-area-inset-bottom,0px));box-shadow:0 -10px 40px rgba(0,0,0,.25);max-height:88vh;overflow:auto");
  card.setAttribute("role","dialog");card.setAttribute("aria-label","دلیل نارضایتی");
  card.appendChild(el("div","font-weight:700;font-size:16px;margin-bottom:4px","مشکل پاسخ چی بود؟"));
  card.appendChild(el("div","font-size:12px;color:var(--mu,#667);margin-bottom:10px","با ثبت، سؤال و پاسخ همین گفتگو برای بهبود بات ذخیره می‌شود."));
  var box=el("div","display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px");
  var btns=[];
  REASONS.forEach(function(r){
    var b=el("button","border:1px solid var(--ln,#ddd);background:var(--s2,#f0f0f4);color:inherit;border-radius:99px;padding:7px 14px;font:inherit;cursor:pointer",r[1]);
    b.type="button";
    b.addEventListener("click",function(){chosen=r[0];btns.forEach(function(x){x.style.borderColor="var(--ln,#ddd)";x.style.background="var(--s2,#f0f0f4)"});b.style.borderColor="var(--ac,#5b5bf5)";b.style.background="var(--acs,#ececff)"});
    btns.push(b);box.appendChild(b);
  });
  card.appendChild(box);
  var ta=el("textarea","width:100%;min-height:62px;border:1px solid var(--ln,#ddd);border-radius:14px;padding:8px 10px;background:var(--bg,#fff);color:inherit;font:inherit;resize:vertical");
  ta.setAttribute("maxlength","300");ta.setAttribute("placeholder","توضیح کوتاه (اختیاری)");card.appendChild(ta);
  var row=el("div","display:flex;gap:10px;margin-top:12px;align-items:center");
  var ok=el("button","background:var(--ac,#5b5bf5);color:#fff;border:0;border-radius:14px;padding:9px 20px;font:inherit;cursor:pointer","ثبت");
  ok.type="button";
  var skip=el("button","background:none;border:1px solid var(--ln,#ddd);color:inherit;border-radius:14px;padding:9px 16px;font:inherit;cursor:pointer","بعداً");
  skip.type="button";
  var del=el("button","margin-inline-start:auto;background:none;border:0;color:var(--mu,#667);font:inherit;font-size:12px;text-decoration:underline;cursor:pointer","حذف همهٔ داده‌های بازخوردم");
  del.type="button";
  ok.addEventListener("click",function(){closeSheet();send(id,"down",{reason:chosen,comment:ta.value}).then(function(){say("ثبت شد، ممنون 🙏")})});
  skip.addEventListener("click",closeSheet);
  del.addEventListener("click",function(){if(!confirm("همهٔ نظرها و لاگ‌های ثبت‌شدهٔ تو حذف شود؟"))return;closeSheet();post("/api/feedback/delete",{}).then(function(r){say(r&&r.ok?"حذف شد":"حذف ناموفق بود")})});
  wrap.addEventListener("click",function(e){if(e.target===wrap)closeSheet()});
  row.appendChild(ok);row.appendChild(skip);row.appendChild(del);card.appendChild(row);wrap.appendChild(card);
  (document.body||document.documentElement).appendChild(wrap);
}
function onChange(id,v){
  var vote=mapVote(v);
  send(id,vote);
  if(vote==="down")sheet(id);else closeSheet();
}
function handle(newVal){
  var cur;try{cur=JSON.parse(newVal||"{}")||{}}catch(e){return}
  var changed=[];
  Object.keys(cur).forEach(function(id){if((cur[id]||"")!==(prev[id]||""))changed.push([id,cur[id]])});
  Object.keys(prev).forEach(function(id){if(!(id in cur)&&prev[id])changed.push([id,""])});
  prev=cur;
  changed.slice(0,3).forEach(function(c){onChange(c[0],c[1])});
}
try{
  var proto=Object.getPrototypeOf(window.localStorage)||Storage.prototype;
  var orig=proto.setItem;
  proto.setItem=function(k,v){
    var r=orig.apply(this,arguments);
    try{if(k===KEY)handle(v)}catch(e){}
    return r;
  };
}catch(e){}
})();
