/*
 * Native Android bridge injected by scripts/prepare_web_assets.py.
 * Images are sent only while the user's Gemini Live session is active.
 * Screen capture starts only after Android MediaProjection consent.
 */
(() => {
  'use strict';
  if (window.__allBatNativeBridgeInstalled) return;
  window.__allBatNativeBridgeInstalled = true;

  const native = window.AndroidAssistant || null;

  document.addEventListener('click', event => {
    try {
      const target = event.target;
      if (!target || typeof target.closest !== 'function') return;
      if (target.closest('[data-act="pick-camera"]')) {
        native && native.markNextFileChooserAsCamera();
      }
      const liveButton = target.closest('[data-act="voicechat"]');
      if (!liveButton || !native || typeof native.hasFloatingAssistantOverlayPermission !== 'function') return;
      // In the regular app, request the special overlay permission before opening Live so Android
      // Settings cannot unexpectedly cover an already-running microphone session. The system's
      // default-assistant surface has its own lifecycle and asks only after Live is explicitly tapped.
      let systemAssistantSurface = false;
      try { systemAssistantSurface = typeof native.isAssistantSession === 'function' && !!native.isAssistantSession(); } catch (_) {}
      if (systemAssistantSurface || native.hasFloatingAssistantOverlayPermission()) return;
      // Ask only once automatically. If the user declines, Live still remains usable without the orb.
      if (typeof native.shouldPromptFloatingAssistantOverlay === 'function' && !native.shouldPromptFloatingAssistantOverlay()) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      try { native.requestFloatingAssistantOverlay(); } catch (_) {}
      setTimeout(() => setAssistantStatus('مجوز حباب شناور را فعال کن؛ بعد از بازگشت دوباره دکمهٔ گفت‌وگوی صوتی را بزن.'), 100);
    } catch (_) {}
  }, true);

  // If the WebView/Android audio stack cannot initialize capture, release native audio focus
  // before bubbling the original error to the Live UI. Native code prepares communication mode
  // when the WebView's own permission request is granted.
  try {
    const mediaDevices = navigator.mediaDevices;
    if (native && mediaDevices && typeof mediaDevices.getUserMedia === 'function' && !mediaDevices.__allBatAudioWrapped) {
      const originalGetUserMedia = mediaDevices.getUserMedia.bind(mediaDevices);
      const wrappedGetUserMedia = async function (constraints) {
        const wantsAudio = !!(constraints && constraints.audio);
        if (wantsAudio) {
          // Set communication mode before Chromium initializes the native audio source.
          try { native.prepareAudioSession(); } catch (_) {}
        }
        try {
          return await originalGetUserMedia(constraints);
        } catch (firstError) {
          // Some Android WebView/audio-driver combinations reject enhanced mic constraints
          // with NotReadableError even though the default microphone works. Retry once with
          // the browser's default audio constraints, then surface the original error if needed.
          const retryable = wantsAudio && constraints.audio && typeof constraints.audio === 'object' &&
            firstError && ['NotReadableError', 'AbortError', 'OverconstrainedError'].includes(firstError.name);
          if (retryable) {
            try {
              return await originalGetUserMedia({ audio: true, video: constraints.video || false });
            } catch (fallbackError) {
              console.warn('Default microphone fallback also failed', fallbackError);
            }
          }
          if (wantsAudio) {
            try { native.cancelAudioSession(); } catch (_) {}
          }
          throw firstError;
        }
      };
      Object.defineProperty(mediaDevices, '__allBatAudioWrapped', { value: true, configurable: false });
      mediaDevices.getUserMedia = wrappedGetUserMedia;
    }
  } catch (error) {
    console.warn('All Bat could not install audio cleanup wrapper', error);
  }

  let cameraStream = null;
  let cameraVideo = null;
  let cameraCanvas = null;
  let cameraTimer = 0;
  let cameraActive = false;
  let voiceServiceActive = false;
  let screenShareActive = false;
  let screenPermissionPending = false;
  let lastFrameSentAt = 0;
  let menuOpen = false;

  const canSendLiveFrame = () => {
    try {
      return typeof state !== 'undefined' && !!state.voiceConversation &&
        typeof liveReady !== 'undefined' && !!liveReady &&
        typeof liveSocket !== 'undefined' && liveSocket &&
        liveSocket.readyState === WebSocket.OPEN;
    } catch (_) { return false; }
  };

  function pushFrame(base64Jpeg) {
    if (!base64Jpeg || !canSendLiveFrame()) return false;
    const now = Date.now();
    // Limit bandwidth, processing load and battery use when camera and screen are both enabled.
    if (now - lastFrameSentAt < 1_100) return false;
    try {
      liveSocket.send(JSON.stringify({
        realtimeInput: {
          video: { mimeType: 'image/jpeg', data: base64Jpeg }
        }
      }));
      lastFrameSentAt = now;
      setStatus('تصویر به گفت‌وگوی زنده فرستاده می‌شود');
      return true;
    } catch (_) {
      setStatus('اتصال زنده آمادهٔ دریافت تصویر نیست');
      return false;
    }
  }

  function setStatus(text) {
    const node = document.getElementById('__allbat_status');
    if (node) node.textContent = String(text || '');
  }

  const style = document.createElement('style');
  style.textContent = `
    #__allbat_widget{position:fixed;z-index:2147483000;right:10px;bottom:calc(88px + env(safe-area-inset-bottom,0px));font:13px/1.45 system-ui,sans-serif;direction:rtl;color:#f8f9ff;max-width:calc(100vw - 20px)}
    #__allbat_toggle{border:0;border-radius:999px;background:linear-gradient(135deg,#5558f3,#15aeca);color:#fff;padding:11px 15px;box-shadow:0 6px 22px #0004;font-weight:700}
    #__allbat_menu{display:none;min-width:210px;margin-bottom:8px;padding:9px;border:1px solid #ffffff2a;border-radius:18px;background:#151a29f5;box-shadow:0 12px 32px #0005;backdrop-filter:blur(18px)}
    #__allbat_menu.open{display:flex;flex-direction:column;gap:7px}
    #__allbat_menu button{border:1px solid #ffffff18;border-radius:12px;background:#252c40;color:#f7f8ff;padding:10px;text-align:right}
    #__allbat_status{padding:4px 3px;color:#c6cce2;font-size:11px;min-height:18px}
    #__allbat_camera_preview{position:fixed;z-index:2147482998;left:10px;bottom:calc(88px + env(safe-area-inset-bottom,0px));width:min(44vw,210px);border:1px solid #ffffff55;border-radius:16px;overflow:hidden;background:#101522;box-shadow:0 8px 24px #0005;display:none}
    #__allbat_camera_preview video{display:block;width:100%;max-height:250px;object-fit:cover;transform:scaleX(1)}
    #__allbat_camera_preview .cap{padding:5px 8px;font-size:11px;color:#fff;background:#101522}
    #__allbat_assistant_mode_banner{display:none;position:fixed;z-index:2147483001;top:calc(8px + env(safe-area-inset-top,0px));left:10px;right:10px;padding:11px 12px;border:1px solid #ffffff24;border-radius:16px;background:#151a29f2;color:#fff;box-shadow:0 8px 28px #0004;direction:rtl;font:13px/1.5 system-ui,sans-serif;align-items:center;gap:10px}
    #__allbat_assistant_mode_banner.show{display:flex}
    #__allbat_assistant_mode_banner .desc{flex:1;min-width:0}
    #__allbat_assistant_mode_banner button{border:0;border-radius:12px;background:#5558f3;color:white;font-weight:700;padding:9px 11px;white-space:nowrap}
    #__allbat_region_modal{position:fixed;inset:0;z-index:2147483646;background:#080d18f5;display:flex;flex-direction:column;gap:10px;padding:calc(12px + env(safe-area-inset-top,0px)) 12px calc(12px + env(safe-area-inset-bottom,0px));box-sizing:border-box;color:#fff;direction:rtl;font:14px/1.5 system-ui,sans-serif;touch-action:pan-y}
    #__allbat_region_modal .region-head,#__allbat_region_modal .region-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
    #__allbat_region_modal .region-head strong{font-size:15px}
    #__allbat_region_modal button{border:1px solid #ffffff26;border-radius:12px;background:#252c40;color:#fff;padding:10px 13px;font-weight:700}
    #__allbat_region_modal button.primary{background:#5558f3;border-color:transparent}
    #__allbat_region_modal button:disabled{opacity:.42}
    #__allbat_region_modal .region-help{font-size:12px;color:#c8d0e4}
    #__allbat_region_modal .region-stage{flex:1;min-height:80px;display:flex;align-items:center;justify-content:center;overflow:hidden;touch-action:none;user-select:none}
    #__allbat_region_modal .region-wrap{position:relative;display:inline-block;max-width:100%;max-height:calc(100vh - 200px);max-height:calc(100dvh - 200px);line-height:0;touch-action:none;user-select:none}
    #__allbat_region_modal .region-image{display:block;width:auto;height:auto;max-width:calc(100vw - 24px);max-height:calc(100vh - 200px);max-height:calc(100dvh - 200px);object-fit:contain;pointer-events:none;user-select:none}
    #__allbat_region_modal .region-box{position:absolute;display:none;border:2px solid #7c9dff;background:#587cff38;box-shadow:0 0 0 9999px #0005;pointer-events:none;box-sizing:border-box}
    @media(prefers-reduced-motion:reduce){#__allbat_toggle{transition:none}} 
  `;
  document.documentElement.appendChild(style);

  const widget = document.createElement('div');
  widget.id = '__allbat_widget';
  widget.innerHTML = `
    <div id="__allbat_menu" aria-label="ابزارهای دستیار اندروید">
      <button id="__allbat_camera" type="button">📷 روشن‌کردن دوربین زنده</button>
      <button id="__allbat_screen" type="button">🖥️ اشتراک‌گذاری صفحه</button>
      <button id="__allbat_overlay" type="button">🔵 فعال‌کردن حباب شناور Digi</button>
      <button id="__allbat_role" type="button">🤖 انتخاب به‌عنوان دستیار پیش‌فرض</button>
      <div id="__allbat_status" role="status">برای ارسال تصویر، گفت‌وگوی زنده را شروع کن.</div>
    </div>
    <button id="__allbat_toggle" type="button" aria-expanded="false">⚡ ابزارهای اندروید</button>
  `;
  document.body.appendChild(widget);

  const preview = document.createElement('div');
  preview.id = '__allbat_camera_preview';
  preview.innerHTML = '<video playsinline muted autoplay></video><div class="cap">پیش‌نمایش دوربین · ارسال فقط هنگام Live</div>';
  document.body.appendChild(preview);
  const previewVideo = preview.querySelector('video');

  const toggle = document.getElementById('__allbat_toggle');
  const menu = document.getElementById('__allbat_menu');
  const cameraButton = document.getElementById('__allbat_camera');
  const screenButton = document.getElementById('__allbat_screen');
  let assistantScreenshotDataUrl = '';
  let assistantPanelBanner = null;
  let regionModal = null;

  function setAssistantStatus(message) {
    setStatus(message);
    if (assistantPanelBanner) {
      const status = assistantPanelBanner.querySelector('.desc');
      if (status) status.textContent = message;
    }
  }

  function closeRegionModal() {
    if (regionModal) regionModal.remove();
    regionModal = null;
  }

  function openAssistantRegionSelector() {
    if (!assistantScreenshotDataUrl) {
      setAssistantStatus('تصویر صفحه در دسترس نیست؛ ممکن است برنامهٔ فعلی اشتراک اسکرین‌شات را مسدود کرده باشد.');
      return;
    }
    closeRegionModal();
    const modal = document.createElement('div');
    modal.id = '__allbat_region_modal';
    modal.innerHTML = `
      <div class="region-head"><strong>انتخاب بخشی از صفحه</strong><button type="button" data-region-cancel>بستن</button></div>
      <div class="region-help">روی تصویر بکش تا فقط همان قسمت انتخاب شود. کل صفحه ارسال نمی‌شود.</div>
      <div class="region-stage"><div class="region-wrap"><img class="region-image" alt="تصویر صفحه برای انتخاب ناحیه"><div class="region-box"></div></div></div>
      <div class="region-foot"><span class="region-help" data-region-status>محدودهٔ دلخواه را با انگشت مشخص کن.</span><button class="primary" type="button" data-region-send disabled>افزودن بخش انتخاب‌شده به پیش‌نویس</button></div>
    `;
    document.body.appendChild(modal);
    regionModal = modal;
    const image = modal.querySelector('.region-image');
    const wrap = modal.querySelector('.region-wrap');
    const box = modal.querySelector('.region-box');
    const sendButton = modal.querySelector('[data-region-send]');
    const status = modal.querySelector('[data-region-status]');
    image.src = assistantScreenshotDataUrl;
    let start = null;
    let selection = null;
    let activePointerId = null;
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const pointFor = event => {
      const r = image.getBoundingClientRect();
      return { x: clamp(event.clientX - r.left, 0, r.width), y: clamp(event.clientY - r.top, 0, r.height) };
    };
    const drawBox = (a, b) => {
      const left = Math.min(a.x, b.x), top = Math.min(a.y, b.y);
      const width = Math.abs(b.x - a.x), height = Math.abs(b.y - a.y);
      box.style.display = 'block';
      box.style.left = left + 'px'; box.style.top = top + 'px';
      box.style.width = width + 'px'; box.style.height = height + 'px';
      return {left, top, width, height};
    };
    wrap.addEventListener('pointerdown', event => {
      if (!image.naturalWidth || !image.naturalHeight) return;
      event.preventDefault();
      activePointerId = event.pointerId;
      try { wrap.setPointerCapture(activePointerId); } catch (_) {}
      start = pointFor(event); selection = null; sendButton.disabled = true;
      drawBox(start, start);
      status.textContent = 'برای تعیین اندازه، انگشتت را حرکت بده.';
    });
    wrap.addEventListener('pointermove', event => {
      if (!start || event.pointerId !== activePointerId) return;
      event.preventDefault();
      const p = pointFor(event); selection = drawBox(start, p);
      sendButton.disabled = selection.width < 14 || selection.height < 14;
    });
    const finishPointer = event => {
      if (!start || event.pointerId !== activePointerId) return;
      const p = pointFor(event); selection = drawBox(start, p);
      start = null; activePointerId = null;
      const valid = selection.width >= 14 && selection.height >= 14;
      sendButton.disabled = !valid;
      status.textContent = valid ? 'محدوده آماده است؛ فقط همین کادر پیوست می‌شود.' : 'محدوده خیلی کوچک است؛ دوباره انتخاب کن.';
    };
    wrap.addEventListener('pointerup', finishPointer);
    wrap.addEventListener('pointercancel', finishPointer);
    modal.querySelector('[data-region-cancel]').addEventListener('click', () => {
      closeRegionModal(); setAssistantStatus('انتخاب بخش صفحه لغو شد؛ هیچ تصویری ارسال نشد.');
    });
    sendButton.addEventListener('click', async () => {
      if (!selection || !image.naturalWidth || !image.naturalHeight) return;
      sendButton.disabled = true;
      status.textContent = 'در حال آماده‌سازی بخش انتخاب‌شده…';
      try {
        const sx = image.naturalWidth / image.getBoundingClientRect().width;
        const sy = image.naturalHeight / image.getBoundingClientRect().height;
        let sx0 = Math.round(selection.left * sx), sy0 = Math.round(selection.top * sy);
        let sw = Math.round(selection.width * sx), sh = Math.round(selection.height * sy);
        sx0 = clamp(sx0, 0, image.naturalWidth - 1); sy0 = clamp(sy0, 0, image.naturalHeight - 1);
        sw = clamp(sw, 1, image.naturalWidth - sx0); sh = clamp(sh, 1, image.naturalHeight - sy0);
        const canvas = document.createElement('canvas');
        const scale = Math.min(1, 1600 / Math.max(sw, sh));
        canvas.width = Math.max(1, Math.round(sw * scale));
        canvas.height = Math.max(1, Math.round(sh * scale));
        const ctx = canvas.getContext('2d', { alpha: false });
        if (!ctx) throw new Error('canvas unavailable');
        ctx.drawImage(image, sx0, sy0, sw, sh, 0, 0, canvas.width, canvas.height);
        const blob = await new Promise((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('crop failed')), 'image/jpeg', 0.88));
        const file = new File([blob], 'allbat-selected-screen-region.jpg', { type: 'image/jpeg', lastModified: Date.now() });
        let attached = false;
        try {
          if (typeof addFiles === 'function') { await Promise.resolve(addFiles([file])); attached = true; }
        } catch (error) { console.warn('Could not attach cropped assistant image', error); }
        if (!attached) {
          const input = document.getElementById('pickerPhoto') || document.querySelector('input[type="file"][accept*="image"]');
          if (input && typeof DataTransfer !== 'undefined') {
            const transfer = new DataTransfer(); transfer.items.add(file); input.files = transfer.files;
            input.dispatchEvent(new Event('change', { bubbles: true })); attached = true;
          }
        }
        if (!attached) throw new Error('composer attachment handler unavailable');
        closeRegionModal();
        setAssistantStatus('فقط بخش انتخاب‌شده به پیش‌نویس پیوست شد. متن سؤال را بنویس و ارسال کن.');
      } catch (error) {
        console.warn('Selected screen region could not be attached', error);
        status.textContent = 'افزودن تصویر ناموفق بود؛ دوباره امتحان کن.';
        sendButton.disabled = false;
      }
    });
  }

  let panelModeStyle = null;
  let panelModeBooting = false;
  function ensureAssistantPanelStyles() {
    if (panelModeStyle) return;
    panelModeStyle = document.createElement('style');
    panelModeStyle.id = '__allbat_assistant_panel_styles';
    panelModeStyle.textContent = `
      html,body{height:100%!important;min-height:0!important;overflow:hidden!important;background:#f9fbff!important}
      body.allbat-assistant-panel-mode .app{height:100dvh!important;min-height:0!important;max-width:none!important;margin:0!important;padding:0 0 2px!important;overflow:auto!important;background:#f9fbff!important}
      body.allbat-assistant-panel-mode .top,body.allbat-assistant-panel-mode .tabs,body.allbat-assistant-panel-mode #topMain,body.allbat-assistant-panel-mode #topChat{display:none!important}
      body.allbat-assistant-panel-mode .screen:not(.on){display:none!important}
      body.allbat-assistant-panel-mode .screen.on{padding:5px 10px!important}
      body.allbat-assistant-panel-mode .hero{display:none!important}
      body.allbat-assistant-panel-mode .sec{display:none!important}
      body.allbat-assistant-panel-mode #msgs{max-height:calc(100dvh - 138px)!important;min-height:65px!important;overflow:auto!important;padding:7px 10px 12px!important;gap:12px!important;scrollbar-width:thin}
      body.allbat-assistant-panel-mode .msg.user .mb{max-width:94%!important;padding:9px 13px!important}
      body.allbat-assistant-panel-mode .msg:not(.user) .mb{max-width:100%!important;border:1px solid #e1e8f4!important;border-radius:20px!important;background:#fff!important;padding:10px 12px!important;box-shadow:0 4px 16px #3150800b}
      body.allbat-assistant-panel-mode .mh{font-size:10px!important}
      body.allbat-assistant-panel-mode .ma{flex-wrap:wrap!important}
      body.allbat-assistant-panel-mode .dock{display:block!important;position:fixed!important;inset-inline:0!important;bottom:0!important;width:100%!important;max-width:none!important;margin:0!important;padding:8px 10px calc(8px + env(safe-area-inset-bottom,0px))!important;background:linear-gradient(transparent,#f9fbff 25%)!important;box-sizing:border-box!important}
      body.allbat-assistant-panel-mode .comp{border-radius:28px!important;background:#fff!important;border:1px solid #dfe7f5!important;box-shadow:0 5px 20px #24477e14!important;padding:6px!important;gap:4px!important}
      body.allbat-assistant-panel-mode .comp textarea{min-height:40px!important;max-height:82px!important;padding:8px 5px!important;font-size:14px!important}
      body.allbat-assistant-panel-mode .rb{width:38px!important;height:38px!important}
      body.allbat-assistant-panel-mode .start{padding:15px 10px 5px!important;gap:6px!important}
      body.allbat-assistant-panel-mode .start h3{font-size:16px!important}
      body.allbat-assistant-panel-mode .start p{font-size:11px!important}
      body.allbat-assistant-panel-mode #__allbat_widget,body.allbat-assistant-panel-mode #__allbat_camera_preview{display:none!important}
      body.allbat-assistant-panel-mode #__allbat_assistant_mode_banner{position:relative!important;inset:auto!important;z-index:2!important;display:flex!important;margin:8px 10px 4px!important;padding:7px 9px!important;background:linear-gradient(120deg,#fff,#eef5ff)!important;border:1px solid #dce7f8!important;border-radius:17px!important;color:#1d2c49!important;box-shadow:0 4px 14px #25497e0d!important;font-size:11px!important}
      body.allbat-assistant-panel-mode #__allbat_assistant_mode_banner .desc{color:#66738c!important}
      body.allbat-assistant-panel-mode #__allbat_assistant_mode_banner button{padding:7px 9px!important;background:#d8e7ff!important;color:#214b93!important;font-size:11px!important}
      body.allbat-assistant-panel-mode .shw{z-index:2147483647!important}
      @media(prefers-reduced-motion:reduce){body.allbat-assistant-panel-mode *{animation:none!important;transition:none!important}}
    `;
    document.head.appendChild(panelModeStyle);
  }

  window.__allbatAssistantPanelMode = enabled => {
    if (!enabled) {
      document.body.classList.remove('allbat-assistant-panel-mode');
      if (assistantPanelBanner) assistantPanelBanner.remove();
      assistantPanelBanner = null;
      return;
    }
    ensureAssistantPanelStyles();
    document.body.classList.add('allbat-assistant-panel-mode');
    if (!assistantPanelBanner) {
      assistantPanelBanner = document.createElement('div');
      assistantPanelBanner.id = '__allbat_assistant_mode_banner';
      assistantPanelBanner.innerHTML = '<div class="desc"><b style="display:block;color:#1d2c49;font-size:12px">Digi</b>برای تحلیل صفحه، یک محدوده انتخاب کن.</div><button type="button">انتخاب بخش</button>';
      assistantPanelBanner.querySelector('button').addEventListener('click', () => {
        try {
          if (native && typeof native.selectScreenRegion === 'function') native.selectScreenRegion();
          else openAssistantRegionSelector();
        } catch (_) { openAssistantRegionSelector(); }
      });
      document.body.appendChild(assistantPanelBanner);
    }
    assistantPanelBanner.classList.add('show');
    // The system assistant is a compact conversation surface, not the full app dashboard.
    // Reuse the existing chat/API implementation instead of introducing a parallel chat stack.
    if (!panelModeBooting) {
      panelModeBooting = true;
      setTimeout(async () => {
        try {
          if (typeof cur === 'function' && typeof newSession === 'function') {
            const current = cur();
            if (!current || current.type !== 'text') await newSession('text');
            else if (typeof go === 'function') go('chat');
          }
          document.body.classList.add('allbat-assistant-panel-mode');
          if (typeof render === 'function') render();
          const input = document.getElementById('inp');
          if (input) input.setAttribute('placeholder', 'از Digi بپرس…');
        } catch (error) {
          console.warn('Could not prepare the compact assistant chat', error);
        } finally {
          panelModeBooting = false;
        }
      }, 220);
    }
  };

  window.__allbatAssistantSetScreenshot = dataUrl => {
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/jpeg;base64,')) return;
    assistantScreenshotDataUrl = dataUrl;
    setAssistantStatus('تصویر صفحه آماده است؛ انتخاب کن کدام بخش به پیش‌نویس پیوست شود.');
  };
  window.__allbatAssistantScreenshotUnavailable = () => {
    assistantScreenshotDataUrl = '';
    setAssistantStatus('اسکرین‌شات از برنامهٔ فعلی دریافت نشد؛ ممکن است تنظیمات حریم خصوصی یا سیستم آن را محدود کرده باشد.');
  };
  window.__allbatAssistantStartRegionSelection = openAssistantRegionSelector;

  toggle.addEventListener('click', () => {
    menuOpen = !menuOpen;
    menu.classList.toggle('open', menuOpen);
    toggle.setAttribute('aria-expanded', String(menuOpen));
  });

  function stopCamera() {
    if (cameraTimer) clearInterval(cameraTimer);
    cameraTimer = 0;
    if (cameraStream) {
      try { cameraStream.getTracks().forEach(track => track.stop()); } catch (_) {}
    }
    cameraStream = null;
    cameraActive = false;
    try { previewVideo.pause(); previewVideo.srcObject = null; } catch (_) {}
    preview.style.display = 'none';
    cameraButton.textContent = '📷 روشن‌کردن دوربین زنده';
    try { native && native.stopCameraSession(); } catch (_) {}
    setStatus('دوربین خاموش شد');
  }

  async function startCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStatus('دسترسی دوربین در این نسخهٔ WebView در دسترس نیست');
      return;
    }
    try {
      setStatus('در انتظار مجوز دوربین…');
      cameraStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 640 }, height: { ideal: 480 },
          frameRate: { ideal: 12, max: 15 }
        }
      });
      previewVideo.srcObject = cameraStream;
      await previewVideo.play();
      preview.style.display = 'block';
      cameraActive = true;
      cameraButton.textContent = '⏹ خاموش‌کردن دوربین';
      try { native && native.startCameraSession(); } catch (_) {}
      if (!cameraCanvas) cameraCanvas = document.createElement('canvas');
      const context = cameraCanvas.getContext('2d', { alpha: false });
      cameraTimer = setInterval(() => {
        if (!cameraActive || !previewVideo.videoWidth || !context) return;
        if (!canSendLiveFrame()) return;
        const scale = Math.min(1, 640 / previewVideo.videoWidth);
        cameraCanvas.width = Math.max(1, Math.round(previewVideo.videoWidth * scale));
        cameraCanvas.height = Math.max(1, Math.round(previewVideo.videoHeight * scale));
        try {
          context.drawImage(previewVideo, 0, 0, cameraCanvas.width, cameraCanvas.height);
          const dataUrl = cameraCanvas.toDataURL('image/jpeg', 0.5);
          pushFrame(dataUrl.slice(dataUrl.indexOf(',') + 1));
        } catch (_) {}
      }, 1_150);
      setStatus(canSendLiveFrame() ? 'دوربین آمادهٔ ارسال تصویر است' : 'پیش‌نمایش روشن است؛ برای ارسال تصویر، گفت‌وگوی زنده را شروع کن.');
    } catch (error) {
      stopCamera();
      setStatus('مجوز یا دسترسی دوربین فراهم نشد');
      console.warn('All Bat camera start failed', error);
    }
  }

  cameraButton.addEventListener('click', () => {
    if (cameraActive) stopCamera(); else startCamera();
  });

  screenButton.addEventListener('click', () => {
    if (screenPermissionPending) return;
    if (!native) {
      setStatus('پل اندروید در دسترس نیست');
      return;
    }
    if (screenShareActive) {
      try { native.stopScreenShare(); } catch (_) { setStatus('توقف اشتراک صفحه ممکن نشد'); }
      return;
    }
    if (!canSendLiveFrame()) {
      if (native && typeof native.selectScreenRegion === 'function') {
        try { native.selectScreenRegion(); setAssistantStatus('انتخاب محدودهٔ صفحه را انجام بده.'); }
        catch (_) { setAssistantStatus('انتخاب محدوده ممکن نشد.'); }
        return;
      }
      setStatus('ابتدا گفت‌وگوی زنده را شروع کن؛ سپس اشتراک صفحه را روشن کن.');
      return;
    }
    screenPermissionPending = true;
    setStatus('در انتظار مجوز اعلان و تأیید سیستم برای اشتراک صفحه…');
    try { native.startScreenShare(); }
    catch (_) {
      screenPermissionPending = false;
      setStatus('شروع اشتراک صفحه ممکن نشد');
    }
  });

  document.getElementById('__allbat_role').addEventListener('click', () => {
    try { native && native.requestDefaultAssistant(); }
    catch (_) { setStatus('تنظیم دستیار پیش‌فرض در دسترس نیست'); }
  });
  document.getElementById('__allbat_overlay').addEventListener('click', () => {
    try {
      if (native && typeof native.requestFloatingAssistantOverlay === 'function') {
        native.requestFloatingAssistantOverlay();
        setAssistantStatus('تنظیمات نمایش روی برنامه‌های دیگر باز می‌شود؛ اجازهٔ حباب شناور را فعال کن.');
      } else {
        setAssistantStatus('حباب شناور فقط در نسخهٔ اندروید قابل فعال‌سازی است.');
      }
    } catch (_) { setAssistantStatus('بازکردن تنظیمات حباب شناور ممکن نشد.'); }
  });

  window.__allbatToggleMicrophone = () => {
    try {
      if (typeof toggleLiveMute === 'function') { toggleLiveMute(); return true; }
    } catch (error) { console.warn('Could not toggle Live microphone', error); }
    setAssistantStatus('کنترل میکروفون فقط هنگام فعال بودن گفت‌وگوی زنده در دسترس است.');
    return false;
  };
  window.__allbatToggleCamera = () => {
    try { cameraButton.click(); return true; }
    catch (error) { console.warn('Could not toggle Live camera', error); return false; }
  };
  window.__allbatToggleScreen = () => {
    try { screenButton.click(); return true; }
    catch (error) { console.warn('Could not toggle screen sharing', error); return false; }
  };
  window.__allbatOverlayOpenApp = () => {
    try { if (typeof go === 'function') go('chat'); } catch (_) {}
    try { document.getElementById('inp')?.focus({ preventScroll: true }); } catch (_) {}
    return true;
  };

  window.__assistantNativeFrame = pushFrame;
  window.__assistantNativeScreenStarted = () => {
    screenPermissionPending = false;
    screenShareActive = true;
    screenButton.textContent = '⏹ توقف اشتراک صفحه';
    setStatus('اشتراک صفحه فعال است؛ فریم‌ها فقط به Live فعال فرستاده می‌شوند');
  };
  window.__assistantNativeScreenStopped = () => {
    screenPermissionPending = false;
    screenShareActive = false;
    screenButton.textContent = '🖥️ اشتراک‌گذاری صفحه';
    setStatus('اشتراک صفحه متوقف شد');
  };
  window.__assistantNativeScreenDenied = () => {
    screenPermissionPending = false;
    setStatus('اشتراک صفحه لغو شد');
  };
  window.__assistantNativeStopAll = () => {
    try { if (typeof stopVoiceConversation === 'function') stopVoiceConversation(false); } catch (_) {}
    stopCamera();
    try { native && native.stopVoiceSession(); } catch (_) {}
    try { native && native.stopScreenShare(); } catch (_) {}
    setStatus('نشست دستیار متوقف شد');
  };
  window.__assistantNativeStartVoiceConversation = () => {
    try {
      if (typeof state !== 'undefined' && state.voiceConversation) return true;
      if (typeof toggleVoiceConversation === 'function') {
        toggleVoiceConversation();
        setStatus('در حال شروع گفت‌وگوی زنده…');
        return true;
      }
    } catch (error) { console.warn('All Bat assistant launch failed', error); }
    setStatus('برای شروع گفت‌وگوی صوتی، صفحهٔ چت را باز کن');
    return false;
  };

  // Keep Android's foreground service alive only while the user-started Live mic is active.
  // The native layer receives a compact transcript/status snapshot for the floating orb.
  let lastOverlaySignature = '';
  let lastOverlayUser = '';
  let lastOverlayAnswer = '';
  let lastUserChangeAt = 0;
  let lastAnswerChangeAt = 0;
  const readLiveUserText = () => {
    try { return typeof liveTurnUserText === 'string' ? liveTurnUserText.trim() : ''; } catch (_) { return ''; }
  };
  const readLiveAnswerText = () => {
    try { return typeof liveTurnAssistantText === 'string' ? liveTurnAssistantText.trim() : ''; } catch (_) { return ''; }
  };
  function publishOverlayState(active) {
    if (!native || typeof native.updateAssistantOverlay !== 'function') return;
    const now = Date.now();
    const userText = readLiveUserText();
    const answerText = readLiveAnswerText();
    if (userText !== lastOverlayUser) { lastOverlayUser = userText; lastUserChangeAt = now; }
    if (answerText !== lastOverlayAnswer) { lastOverlayAnswer = answerText; lastAnswerChangeAt = now; }
    const appGenerating = (() => { try { return !!(typeof state !== 'undefined' && state.sending); } catch (_) { return false; } })();
    const micMuted = (() => { try { return !!(typeof state !== 'undefined' && state.voiceMuted); } catch (_) { return false; } })();
    let generating = appGenerating;
    let status = active ? 'گوش می‌دهم…' : 'دستیار آماده است';
    if (active) {
      if (answerText && now - lastAnswerChangeAt < 2100) {
        status = 'در حال پاسخ‌گویی…';
        generating = true;
      } else if (userText && !answerText && now - lastUserChangeAt > 900) {
        status = 'در حال پردازش پاسخ…';
        generating = true;
      } else if (userText && now - lastUserChangeAt < 1200) {
        status = 'در حال شنیدن…';
      }
    } else if (appGenerating) {
      status = 'Just a sec…';
    }
    const signature = JSON.stringify([userText, answerText, status, generating, micMuted, cameraActive, screenShareActive, active]);
    if (signature === lastOverlaySignature) return;
    lastOverlaySignature = signature;
    try {
      native.updateAssistantOverlay(userText, answerText, status, generating, micMuted, cameraActive, screenShareActive);
    } catch (error) { console.warn('Could not update native assistant overlay', error); }
  }
  setInterval(() => {
    let active = false;
    try {
      active = typeof state !== 'undefined' && !!state.voiceConversation &&
        typeof liveMicStream !== 'undefined' && !!liveMicStream && liveMicStream.active;
    } catch (_) {}
    if (active && !voiceServiceActive) {
      voiceServiceActive = true;
      lastOverlaySignature = '';
      try { native && native.startVoiceSession(); } catch (_) {}
    } else if (!active && voiceServiceActive) {
      voiceServiceActive = false;
      try { native && native.stopVoiceSession(); } catch (_) {}
    }
    publishOverlayState(active);
  }, 650);

  window.addEventListener('beforeunload', () => {
    // Normal backgrounding does not unload the document; actual page teardown releases camera.
    stopCamera();
  });
})();
