/*
 * Native Android bridge injected by scripts/prepare_web_assets.py.
 * Images are sent only while the user's Gemini Live session is active.
 * Screen capture starts only after Android MediaProjection consent.
 */
(() => {
  'use strict';
  if (window.__allBatNativeBridgeInstalled) return;
  window.__allBatNativeBridgeInstalled = true;

  const native = window.AndroidAssistant || null;
  let cameraStream = null;
  let cameraVideo = null;
  let cameraCanvas = null;
  let cameraTimer = 0;
  let cameraActive = false;
  let voiceServiceActive = false;
  let screenShareActive = false;
  let screenPermissionPending = false;
  let lastFrameSentAt = 0;
  let menuOpen = false;

  const canSendLiveFrame = () => {
    try {
      return typeof state !== 'undefined' && !!state.voiceConversation &&
        typeof liveReady !== 'undefined' && !!liveReady &&
        typeof liveSocket !== 'undefined' && liveSocket &&
        liveSocket.readyState === WebSocket.OPEN;
    } catch (_) { return false; }
  };

  function pushFrame(base64Jpeg) {
    if (!base64Jpeg || !canSendLiveFrame()) return false;
    const now = Date.now();
    // Limit bandwidth, processing load and battery use when camera and screen are both enabled.
    if (now - lastFrameSentAt < 1_100) return false;
    try {
      liveSocket.send(JSON.stringify({
        realtimeInput: {
          video: { mimeType: 'image/jpeg', data: base64Jpeg }
        }
      }));
      lastFrameSentAt = now;
      setStatus('تصویر به گفت‌وگوی زنده فرستاده می‌شود');
      return true;
    } catch (_) {
      setStatus('اتصال زنده آمادهٔ دریافت تصویر نیست');
      return false;
    }
  }

  function setStatus(text) {
    const node = document.getElementById('__allbat_status');
    if (node) node.textContent = String(text || '');
  }

  const style = document.createElement('style');
  style.textContent = `
    #__allbat_widget{position:fixed;z-index:2147483000;right:10px;bottom:calc(88px + env(safe-area-inset-bottom,0px));font:13px/1.45 system-ui,sans-serif;direction:rtl;color:#f8f9ff;max-width:calc(100vw - 20px)}
    #__allbat_toggle{border:0;border-radius:999px;background:linear-gradient(135deg,#5558f3,#15aeca);color:#fff;padding:11px 15px;box-shadow:0 6px 22px #0004;font-weight:700}
    #__allbat_menu{display:none;min-width:210px;margin-bottom:8px;padding:9px;border:1px solid #ffffff2a;border-radius:18px;background:#151a29f5;box-shadow:0 12px 32px #0005;backdrop-filter:blur(18px)}
    #__allbat_menu.open{display:flex;flex-direction:column;gap:7px}
    #__allbat_menu button{border:1px solid #ffffff18;border-radius:12px;background:#252c40;color:#f7f8ff;padding:10px;text-align:right}
    #__allbat_status{padding:4px 3px;color:#c6cce2;font-size:11px;min-height:18px}
    #__allbat_camera_preview{position:fixed;z-index:2147482998;left:10px;bottom:calc(88px + env(safe-area-inset-bottom,0px));width:min(44vw,210px);border:1px solid #ffffff55;border-radius:16px;overflow:hidden;background:#101522;box-shadow:0 8px 24px #0005;display:none}
    #__allbat_camera_preview video{display:block;width:100%;max-height:250px;object-fit:cover;transform:scaleX(1)}
    #__allbat_camera_preview .cap{padding:5px 8px;font-size:11px;color:#fff;background:#101522}
    @media(prefers-reduced-motion:reduce){#__allbat_toggle{transition:none}}
  `;
  document.documentElement.appendChild(style);

  const widget = document.createElement('div');
  widget.id = '__allbat_widget';
  widget.innerHTML = `
    <div id="__allbat_menu" aria-label="ابزارهای دستیار اندروید">
      <button id="__allbat_camera" type="button">📷 روشن‌کردن دوربین زنده</button>
      <button id="__allbat_screen" type="button">🖥️ اشتراک‌گذاری صفحه</button>
      <button id="__allbat_role" type="button">🤖 انتخاب به‌عنوان دستیار پیش‌فرض</button>
      <div id="__allbat_status" role="status">برای ارسال تصویر، گفت‌وگوی زنده را شروع کن.</div>
    </div>
    <button id="__allbat_toggle" type="button" aria-expanded="false">⚡ ابزارهای اندروید</button>
  `;
  document.body.appendChild(widget);

  const preview = document.createElement('div');
  preview.id = '__allbat_camera_preview';
  preview.innerHTML = '<video playsinline muted autoplay></video><div class="cap">پیش‌نمایش دوربین · ارسال فقط هنگام Live</div>';
  document.body.appendChild(preview);
  const previewVideo = preview.querySelector('video');

  const toggle = document.getElementById('__allbat_toggle');
  const menu = document.getElementById('__allbat_menu');
  const cameraButton = document.getElementById('__allbat_camera');
  const screenButton = document.getElementById('__allbat_screen');

  toggle.addEventListener('click', () => {
    menuOpen = !menuOpen;
    menu.classList.toggle('open', menuOpen);
    toggle.setAttribute('aria-expanded', String(menuOpen));
  });

  function stopCamera() {
    if (cameraTimer) clearInterval(cameraTimer);
    cameraTimer = 0;
    if (cameraStream) {
      try { cameraStream.getTracks().forEach(track => track.stop()); } catch (_) {}
    }
    cameraStream = null;
    cameraActive = false;
    try { previewVideo.pause(); previewVideo.srcObject = null; } catch (_) {}
    preview.style.display = 'none';
    cameraButton.textContent = '📷 روشن‌کردن دوربین زنده';
    try { native && native.stopCameraSession(); } catch (_) {}
    setStatus('دوربین خاموش شد');
  }

  async function startCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStatus('دسترسی دوربین در این نسخهٔ WebView در دسترس نیست');
      return;
    }
    try {
      setStatus('در انتظار مجوز دوربین…');
      cameraStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 640 }, height: { ideal: 480 },
          frameRate: { ideal: 12, max: 15 }
        }
      });
      previewVideo.srcObject = cameraStream;
      await previewVideo.play();
      preview.style.display = 'block';
      cameraActive = true;
      cameraButton.textContent = '⏹ خاموش‌کردن دوربین';
      try { native && native.startCameraSession(); } catch (_) {}
      if (!cameraCanvas) cameraCanvas = document.createElement('canvas');
      const context = cameraCanvas.getContext('2d', { alpha: false });
      cameraTimer = setInterval(() => {
        if (!cameraActive || !previewVideo.videoWidth || !context) return;
        if (!canSendLiveFrame()) return;
        const scale = Math.min(1, 640 / previewVideo.videoWidth);
        cameraCanvas.width = Math.max(1, Math.round(previewVideo.videoWidth * scale));
        cameraCanvas.height = Math.max(1, Math.round(previewVideo.videoHeight * scale));
        try {
          context.drawImage(previewVideo, 0, 0, cameraCanvas.width, cameraCanvas.height);
          const dataUrl = cameraCanvas.toDataURL('image/jpeg', 0.5);
          pushFrame(dataUrl.slice(dataUrl.indexOf(',') + 1));
        } catch (_) {}
      }, 1_150);
      setStatus(canSendLiveFrame() ? 'دوربین آمادهٔ ارسال تصویر است' : 'پیش‌نمایش روشن است؛ برای ارسال تصویر، گفت‌وگوی زنده را شروع کن.');
    } catch (error) {
      stopCamera();
      setStatus('مجوز یا دسترسی دوربین فراهم نشد');
      console.warn('All Bat camera start failed', error);
    }
  }

  cameraButton.addEventListener('click', () => {
    if (cameraActive) stopCamera(); else startCamera();
  });

  screenButton.addEventListener('click', () => {
    if (screenPermissionPending) return;
    if (!native) {
      setStatus('پل اندروید در دسترس نیست');
      return;
    }
    if (screenShareActive) {
      try { native.stopScreenShare(); } catch (_) { setStatus('توقف اشتراک صفحه ممکن نشد'); }
      return;
    }
    if (!canSendLiveFrame()) {
      setStatus('ابتدا گفت‌وگوی زنده را شروع کن؛ سپس اشتراک صفحه را روشن کن.');
      return;
    }
    screenPermissionPending = true;
    setStatus('در انتظار مجوز اعلان و تأیید سیستم برای اشتراک صفحه…');
    try { native.startScreenShare(); }
    catch (_) {
      screenPermissionPending = false;
      setStatus('شروع اشتراک صفحه ممکن نشد');
    }
  });

  document.getElementById('__allbat_role').addEventListener('click', () => {
    try { native && native.requestDefaultAssistant(); }
    catch (_) { setStatus('تنظیم دستیار پیش‌فرض در دسترس نیست'); }
  });

  window.__assistantNativeFrame = pushFrame;
  window.__assistantNativeScreenStarted = () => {
    screenPermissionPending = false;
    screenShareActive = true;
    screenButton.textContent = '⏹ توقف اشتراک صفحه';
    setStatus('اشتراک صفحه فعال است؛ فریم‌ها فقط به Live فعال فرستاده می‌شوند');
  };
  window.__assistantNativeScreenStopped = () => {
    screenPermissionPending = false;
    screenShareActive = false;
    screenButton.textContent = '🖥️ اشتراک‌گذاری صفحه';
    setStatus('اشتراک صفحه متوقف شد');
  };
  window.__assistantNativeScreenDenied = () => {
    screenPermissionPending = false;
    setStatus('اشتراک صفحه لغو شد');
  };
  window.__assistantNativeStopAll = () => {
    try { if (typeof stopVoiceConversation === 'function') stopVoiceConversation(false); } catch (_) {}
    stopCamera();
    try { native && native.stopVoiceSession(); } catch (_) {}
    try { native && native.stopScreenShare(); } catch (_) {}
    setStatus('نشست دستیار متوقف شد');
  };
  window.__assistantNativeStartVoiceConversation = () => {
    try {
      if (typeof state !== 'undefined' && state.voiceConversation) return true;
      if (typeof toggleVoiceConversation === 'function') {
        toggleVoiceConversation();
        setStatus('در حال شروع گفت‌وگوی زنده…');
        return true;
      }
    } catch (error) { console.warn('All Bat assistant launch failed', error); }
    setStatus('برای شروع گفت‌وگوی صوتی، صفحهٔ چت را باز کن');
    return false;
  };

  // Keep an Android foreground service active only while the existing app-level Live voice
  // session has successfully acquired its microphone. No automatic listening is started.
  setInterval(() => {
    let active = false;
    try {
      active = typeof state !== 'undefined' && !!state.voiceConversation &&
        typeof liveMicStream !== 'undefined' && !!liveMicStream && liveMicStream.active;
    } catch (_) {}
    if (active && !voiceServiceActive) {
      voiceServiceActive = true;
      try { native && native.startVoiceSession(); } catch (_) {}
    } else if (!active && voiceServiceActive) {
      voiceServiceActive = false;
      try { native && native.stopVoiceSession(); } catch (_) {}
    }
  }, 650);

  window.addEventListener('beforeunload', () => {
    // Normal backgrounding does not unload the document; actual page teardown releases camera.
    stopCamera();
  });
})();
