package com.allbat.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

/** Notes stay in the app's private database. No storage or network permission is used. */
internal object LocalNotesStore {
    private const val DB_NAME = "allbat_local_notes.db"
    private const val DB_VERSION = 1
    private const val TABLE = "notes"

    private class Helper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE $TABLE (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "title TEXT NOT NULL," +
                    "content TEXT NOT NULL," +
                    "created_at INTEGER NOT NULL," +
                    "updated_at INTEGER NOT NULL" +
                ")"
            )
            db.execSQL("CREATE INDEX notes_updated_idx ON $TABLE(updated_at DESC)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            // No destructive migration. Future schema changes must preserve existing notes.
        }
    }

    fun save(context: Context, rawTitle: String, rawContent: String): PhoneActionEngine.ToolOutcome {
        val title = rawTitle.trim()
        val content = rawContent.trim()
        if (title.isBlank() || title.length > 120) {
            return PhoneActionEngine.ToolOutcome(false, "عنوان یادداشت باید بین ۱ تا ۱۲۰ نویسه باشد.")
        }
        if (content.isBlank() || content.length > 8000) {
            return PhoneActionEngine.ToolOutcome(false, "متن یادداشت خالی یا بیش از ۸۰۰۰ نویسه است.")
        }
        return try {
            val now = System.currentTimeMillis()
            val values = ContentValues().apply {
                put("title", title)
                put("content", content)
                put("created_at", now)
                put("updated_at", now)
            }
            val helper = Helper(context.applicationContext)
            val id = try {
                helper.writableDatabase.insertOrThrow(TABLE, null, values)
            } finally {
                helper.close()
            }
            PhoneActionEngine.ToolOutcome(
                true,
                "یادداشت «$title» در حافظهٔ داخلی همین برنامه ذخیره شد.",
                JSONObject().put("note_id", id).put("title", title).put("stored_locally", true)
            )
        } catch (_: Exception) {
            PhoneActionEngine.ToolOutcome(false, "ذخیرهٔ یادداشت در حافظهٔ داخلی انجام نشد.")
        }
    }

    fun list(context: Context, requestedCount: Int): PhoneActionEngine.ToolOutcome {
        val limit = requestedCount.coerceIn(1, 20)
        return try {
            val items = JSONArray()
            val helper = Helper(context.applicationContext)
            try {
                helper.readableDatabase.rawQuery(
                    "SELECT id, title, updated_at FROM $TABLE ORDER BY updated_at DESC LIMIT ?",
                    arrayOf(limit.toString())
                ).use { cursor ->
                    while (cursor.moveToNext()) {
                        items.put(JSONObject()
                            .put("note_id", cursor.getLong(0))
                            .put("title", cursor.getString(1))
                            .put("updated_at", cursor.getLong(2)))
                    }
                }
            } finally {
                helper.close()
            }
            val message = if (items.length() == 0) "هنوز یادداشتی در حافظهٔ داخلی All Bat ذخیره نشده است."
                else "${items.length()} یادداشت اخیر پیدا شد. برای خواندن متن یک یادداشت، عنوانش را جستجو کن."
            PhoneActionEngine.ToolOutcome(true, message, JSONObject().put("notes", items).put("count", items.length()))
        } catch (_: Exception) {
            PhoneActionEngine.ToolOutcome(false, "خواندن فهرست یادداشت‌ها انجام نشد.")
        }
    }

    fun search(context: Context, rawQuery: String, requestedCount: Int): PhoneActionEngine.ToolOutcome {
        val query = rawQuery.trim()
        if (query.isBlank() || query.length > 120) {
            return PhoneActionEngine.ToolOutcome(false, "عبارت جستجوی یادداشت باید بین ۱ تا ۱۲۰ نویسه باشد.")
        }
        val limit = requestedCount.coerceIn(1, 5)
        return try {
            val items = JSONArray()
            val helper = Helper(context.applicationContext)
            try {
                helper.readableDatabase.rawQuery(
                    "SELECT id, title, content, updated_at FROM $TABLE " +
                        "WHERE instr(lower(title), lower(?)) > 0 OR instr(lower(content), lower(?)) > 0 " +
                        "ORDER BY updated_at DESC LIMIT ?",
                    arrayOf(query, query, limit.toString())
                ).use { cursor ->
                    while (cursor.moveToNext()) {
                        val noteContent = cursor.getString(2)
                        items.put(JSONObject()
                            .put("note_id", cursor.getLong(0))
                            .put("title", cursor.getString(1))
                            .put("content", noteContent.take(2500))
                            .put("content_truncated", noteContent.length > 2500)
                            .put("updated_at", cursor.getLong(3)))
                    }
                }
            } finally {
                helper.close()
            }
            val message = if (items.length() == 0) "یادداشتی دربارهٔ «$query» پیدا نشد."
                else "${items.length()} یادداشت مرتبط با «$query» پیدا شد."
            PhoneActionEngine.ToolOutcome(true, message,
                JSONObject().put("query", query).put("notes", items).put("count", items.length()))
        } catch (_: Exception) {
            PhoneActionEngine.ToolOutcome(false, "جستجو در یادداشت‌های محلی انجام نشد.")
        }
    }
}
