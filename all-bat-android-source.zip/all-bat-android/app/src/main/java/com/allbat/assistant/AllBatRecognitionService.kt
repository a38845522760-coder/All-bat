package com.allbat.assistant

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * RecognitionService adapter used to satisfy Android's voice-interaction service contract.
 * Listening is delegated only to a non-Google recognizer installed on the device. All Bat does
 * not implement an always-on hotword detector and never records audio without an explicit session.
 */
class AllBatRecognitionService : RecognitionService() {
    private var recognizer: SpeechRecognizer? = null
    private var currentCallback: Callback? = null

    override fun onStartListening(intent: Intent?, callback: Callback?) {
        if (callback == null) return
        currentCallback = null
        clearRecognizer()
        currentCallback = callback
        // This service is declared as the assistant's recognitionService. Calling the default
        // SpeechRecognizer factory here could bind back to this same service and recurse forever.
        // Resolve a different installed recognizer explicitly, preferring a system provider.
        val delegateComponent = findDelegateRecognizer()
        if (delegateComponent == null) {
            callback.error(SpeechRecognizer.ERROR_CLIENT)
            clearRecognizer()
            return
        }

        try {
            val delegate = SpeechRecognizer.createSpeechRecognizer(this, delegateComponent)
            recognizer = delegate
            delegate.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    currentCallback?.readyForSpeech(params ?: Bundle())
                }
                override fun onBeginningOfSpeech() { currentCallback?.beginningOfSpeech() }
                override fun onRmsChanged(rmsdB: Float) { currentCallback?.rmsChanged(rmsdB) }
                override fun onBufferReceived(buffer: ByteArray?) { currentCallback?.bufferReceived(buffer ?: byteArrayOf()) }
                override fun onEndOfSpeech() { currentCallback?.endOfSpeech() }
                override fun onError(error: Int) {
                    val callbackForThisRequest = currentCallback
                    currentCallback = null
                    callbackForThisRequest?.error(error)
                    clearRecognizer()
                }
                override fun onResults(results: Bundle?) {
                    val callbackForThisRequest = currentCallback
                    currentCallback = null
                    callbackForThisRequest?.results(results ?: Bundle())
                    clearRecognizer()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    currentCallback?.partialResults(partialResults ?: Bundle())
                }
                // RecognitionListener requires this callback on Android API levels used by the build.
                // The delegate's generic events are not part of the app's speech-result contract.
                override fun onEvent(eventType: Int, params: Bundle?) {
                    // Intentionally ignored; results and errors are handled above.
                }
            })
            val offlineIntent = Intent(intent ?: Intent()).apply {
                putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                if (!hasExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE)) {
                    putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                }
            }
            delegate.startListening(offlineIntent)
        } catch (_: Exception) {
            callback.error(SpeechRecognizer.ERROR_CLIENT)
            clearRecognizer()
        }
    }

    override fun onStopListening(callback: Callback?) {
        try { recognizer?.stopListening() } catch (_: Exception) {
            callback?.error(SpeechRecognizer.ERROR_CLIENT)
            clearRecognizer()
        }
    }

    override fun onCancel(callback: Callback?) {
        currentCallback = null
        clearRecognizer()
    }

    @Suppress("DEPRECATION")
    private fun findDelegateRecognizer(): ComponentName? {
        val intent = Intent(RecognitionService.SERVICE_INTERFACE).addCategory(Intent.CATEGORY_DEFAULT)
        val services = try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                packageManager.queryIntentServices(
                    intent,
                    PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong())
                )
            } else {
                packageManager.queryIntentServices(intent, PackageManager.MATCH_DEFAULT_ONLY)
            }
        } catch (_: Exception) {
            emptyList()
        }

        val candidates = services.mapNotNull { resolveInfo ->
            val service = resolveInfo.serviceInfo ?: return@mapNotNull null
            if (service.packageName == packageName || !service.exported ||
                service.packageName.startsWith("com.google.") ||
                service.packageName.contains("googlequicksearchbox", ignoreCase = true) ||
                service.permission != "android.permission.BIND_SPEECH_RECOGNITION_SERVICE") {
                return@mapNotNull null
            }
            service
        }
        if (candidates.isEmpty()) return null

        val preferredPackages = listOf(
            "com.samsung.android.bixby.agent",
            "com.samsung.android.svoice"
        )
        val selected = candidates.sortedWith(
            compareBy<android.content.pm.ServiceInfo> {
                when {
                    it.packageName in preferredPackages -> 0
                    (it.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0 -> 1
                    (it.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0 -> 2
                    else -> 3
                }
            }.thenBy { it.packageName }
        ).firstOrNull() ?: return null
        return ComponentName(selected.packageName, selected.name)
    }

    private fun clearRecognizer() {
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }

    override fun onDestroy() {
        clearRecognizer()
        currentCallback = null
        super.onDestroy()
    }
}
