package com.allbat.assistant

import android.app.Service
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

/** A small, user-controlled Gemini-style assistant surface shown only during an explicit Live session. */
internal class FloatingAssistantOverlay(
    private val service: Service,
    private val onAction: (String) -> Unit
) {
    data class State(
        val userText: String = "",
        val answerText: String = "",
        val status: String = "گفت‌وگوی زنده فعال است",
        val generating: Boolean = false,
        val micMuted: Boolean = false,
        val cameraActive: Boolean = false,
        val screenActive: Boolean = false
    )

    companion object {
        const val ACTION_MIC = "mic"
        const val ACTION_CAMERA = "camera"
        const val ACTION_SCREEN = "screen"
        const val ACTION_END = "end"
        const val ACTION_OPEN = "open"
        const val ACTION_COLLAPSE = "collapse"
    }

    private val manager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = service.resources.displayMetrics.density
    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var expanded = false
    private var lastState = State()
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var answerView: TextView? = null
    private var userView: TextView? = null
    private var statusView: TextView? = null
    private var speakerButton: TextView? = null
    private var micButton: TextView? = null
    private var cameraButton: TextView? = null
    private var screenButton: TextView? = null
    private var panelOrbButton: View? = null

    private fun dp(value: Int) = (value * density).toInt()
    private fun gradient(colors: IntArray, radius: Float, stroke: Int = Color.TRANSPARENT) = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, colors
    ).apply {
        cornerRadius = radius
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }
    private fun pillBackground(color: Int, radius: Int = 999) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radius).toFloat()
        setColor(color)
    }

    fun show() {
        if (!canDraw()) return
        if (expanded) showPanel() else showBubble()
    }

    fun update(newState: State) {
        lastState = newState
        if (!canDraw()) {
            removeAll()
            return
        }
        if (expanded) {
            updatePanelContent()
            showPanelIfMissing()
        } else {
            showBubbleIfMissing()
        }
    }

    fun toggleExpanded() {
        expanded = !expanded
        if (expanded) {
            removeBubble()
            showPanel()
        } else {
            removePanel()
            showBubble()
        }
    }

    fun collapse() {
        expanded = false
        removePanel()
        showBubble()
    }

    fun hide() {
        removeAll()
    }

    fun destroy() {
        removeAll()
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        ttsReady = false
    }

    private fun canDraw(): Boolean = Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(service)

    private fun showBubbleIfMissing() {
        if (bubble == null) showBubble()
    }

    private fun showBubble() {
        if (!canDraw()) return
        if (bubble != null) return
        val orb = TextView(service).apply {
            contentDescription = "باز کردن دستیار Digi"
            text = ""
            background = gradient(
                intArrayOf(Color.WHITE, Color.rgb(222, 235, 255), Color.rgb(68, 139, 255)),
                dp(999).toFloat(), Color.rgb(220, 232, 255)
            )
            elevation = dp(9).toFloat()
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            setOnClickListener { toggleExpanded() }
        }
        val params = WindowManager.LayoutParams(
            dp(66), dp(66),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.BOTTOM
            x = dp(18)
            y = dp(125)
            title = "Digi assistant orb"
        }
        orb.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0f
            private var startY = 0f
            private var originX = 0
            private var originY = 0
            private var dragged = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX; startY = event.rawY
                        originX = params.x; originY = params.y
                        dragged = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - startX).toInt()
                        val dy = (event.rawY - startY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) dragged = true
                        if (dragged) {
                            params.x = (originX - dx).coerceAtLeast(0)
                            params.y = (originY - dy).coerceAtLeast(dp(12))
                            try { manager.updateViewLayout(orb, params) } catch (_: Exception) { }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!dragged) v.performClick()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return false
            }
        })
        try {
            manager.addView(orb, params)
            bubble = orb
            bubbleParams = params
        } catch (_: Exception) {
            bubble = null
            bubbleParams = null
        }
    }

    private fun showPanelIfMissing() {
        if (panel == null) showPanel()
    }

    private fun showPanel() {
        if (!canDraw()) return
        if (panel != null) {
            updatePanelContent()
            return
        }
        val screenWidth = service.resources.displayMetrics.widthPixels
        val width = min(screenWidth - dp(20), dp(420)).coerceAtLeast(dp(260))
        val root = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(9))
            background = gradient(
                intArrayOf(Color.rgb(255, 255, 255), Color.rgb(247, 250, 255)),
                dp(28).toFloat(), Color.rgb(222, 230, 243)
            )
            elevation = dp(12).toFloat()
            clipToOutline = true
        }

        // Answer card: live transcript appears here while the assistant is speaking/generating.
        val card = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(10), dp(13), dp(10))
            background = gradient(intArrayOf(Color.WHITE, Color.rgb(250, 252, 255)), dp(22).toFloat(), Color.rgb(229, 235, 246))
        }
        val header = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(service).apply {
            text = "Digi"
            textSize = 15f
            setTextColor(Color.rgb(20, 28, 45))
            setTypeface(typeface, Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(28), 1f))
        val minimise = TextView(service).apply {
            text = "Minimize"
            textSize = 12f
            setTextColor(Color.rgb(40, 73, 135))
            setPadding(dp(10), dp(5), dp(10), dp(5))
            background = pillBackground(Color.rgb(237, 243, 255), 99)
            setOnClickListener { collapse() }
        }
        header.addView(minimise)
        card.addView(header)

        statusView = TextView(service).apply {
            text = lastState.status
            textSize = 11f
            setTextColor(Color.rgb(61, 100, 167))
            setPadding(0, dp(2), 0, dp(3))
        }
        card.addView(statusView)
        userView = TextView(service).apply {
            textSize = 12f
            setTextColor(Color.rgb(105, 114, 130))
            maxLines = 2
            setPadding(0, dp(1), 0, dp(3))
            visibility = View.GONE
        }
        card.addView(userView)

        val answerRow = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        answerView = TextView(service).apply {
            textSize = 14f
            setTextColor(Color.rgb(23, 29, 43))
            maxLines = 5
            ellipsize = android.text.TextUtils.TruncateAt.END
            text = "در خدمتم؛ سؤال خودت را بگو."
        }
        answerRow.addView(answerView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        speakerButton = TextView(service).apply {
            text = "🔊"
            contentDescription = "خواندن پاسخ با صدا"
            textSize = 17f
            gravity = Gravity.CENTER
            background = pillBackground(Color.rgb(217, 232, 255), 999)
            setOnClickListener { readAnswerAloud() }
        }
        answerRow.addView(speakerButton, LinearLayout.LayoutParams(dp(38), dp(38)))
        card.addView(answerRow)
        root.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val controls = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(8), dp(2), 0)
        }
        cameraButton = addControl(controls, "📷", "دوربین", lastState.cameraActive) { onAction(ACTION_CAMERA) }
        screenButton = addControl(controls, "▣", "صفحه", lastState.screenActive) { onAction(ACTION_SCREEN) }
        val orbContainer = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        panelOrbButton = TextView(service).apply {
            text = ""
            contentDescription = "کوچک کردن دستیار"
            background = gradient(intArrayOf(Color.WHITE, Color.rgb(221, 233, 255), Color.rgb(78, 139, 255)), dp(999).toFloat())
            elevation = dp(5).toFloat()
            setOnClickListener { collapse() }
        }
        orbContainer.addView(panelOrbButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        val orbLabel = TextView(service).apply {
            text = "کوچک‌سازی"
            textSize = 9f
            setTextColor(Color.rgb(95, 103, 119))
            gravity = Gravity.CENTER
            maxLines = 1
        }
        orbContainer.addView(orbLabel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)))
        controls.addView(orbContainer, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        micButton = addControl(controls, if (lastState.micMuted) "🎙×" else "🎙", "میکروفون", !lastState.micMuted) { onAction(ACTION_MIC) }
        val endButton = addControl(controls, "✕", "پایان", false) { onAction(ACTION_END) }
        setControlTint(endButton, true, destructive = true)
        root.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val params = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(10)
            title = "Digi assistant controls"
        }
        try {
            manager.addView(root, params)
            panel = root
            panelParams = params
            updatePanelContent()
        } catch (_: Exception) {
            panel = null
            panelParams = null
        }
        ensureTts()
    }

    private fun addControl(parent: LinearLayout, glyph: String, label: String, active: Boolean, callback: () -> Unit): TextView {
        val col = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val icon = TextView(service).apply {
            text = glyph
            textSize = if (glyph == "🎙×") 18f else 21f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(28, 36, 52))
            background = pillBackground(if (active) Color.rgb(211, 229, 255) else Color.rgb(245, 247, 251), 999)
            setOnClickListener { callback() }
            contentDescription = label
        }
        col.addView(icon, LinearLayout.LayoutParams(dp(43), dp(43)))
        val caption = TextView(service).apply {
            text = label
            textSize = 9f
            setTextColor(Color.rgb(95, 103, 119))
            gravity = Gravity.CENTER
            maxLines = 1
        }
        col.addView(caption, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)))
        parent.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return icon
    }

    private fun setControlTint(view: TextView?, active: Boolean, destructive: Boolean = false) {
        if (view == null) return
        view.background = pillBackground(
            when {
                destructive -> Color.rgb(255, 231, 235)
                active -> Color.rgb(211, 229, 255)
                else -> Color.rgb(245, 247, 251)
            }, 999
        )
        view.setTextColor(if (destructive) Color.rgb(190, 39, 63) else Color.rgb(28, 36, 52))
    }

    private fun updatePanelContent() {
        statusView?.text = lastState.status
        val user = lastState.userText.trim()
        userView?.apply {
            text = "تو: $user"
            visibility = if (user.isBlank()) View.GONE else View.VISIBLE
        }
        val answer = lastState.answerText.trim()
        answerView?.text = when {
            answer.isNotBlank() -> answer
            lastState.generating -> "Just a sec…"
            else -> "در خدمتم؛ سؤال خودت را بگو."
        }
        speakerButton?.apply {
            isEnabled = answer.isNotBlank()
            alpha = if (answer.isNotBlank()) 1f else .45f
        }
        setControlTint(cameraButton, lastState.cameraActive)
        setControlTint(screenButton, lastState.screenActive)
        setControlTint(micButton, !lastState.micMuted)
        micButton?.text = if (lastState.micMuted) "🎙×" else "🎙"
    }

    private fun ensureTts() {
        if (tts != null) return
        tts = TextToSpeech(service) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val result = tts?.setLanguage(Locale("fa", "IR"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale("fa")
                }
            }
        }
    }

    private fun readAnswerAloud() {
        val text = lastState.answerText.trim()
        if (text.isBlank()) {
            Toast.makeText(service, "هنوز پاسخی برای خواندن وجود ندارد", Toast.LENGTH_SHORT).show()
            return
        }
        ensureTts()
        if (!ttsReady || tts == null) {
            Toast.makeText(service, "موتور گفتار هنوز آماده نیست", Toast.LENGTH_SHORT).show()
            return
        }
        @Suppress("DEPRECATION")
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null)
    }

    private fun showPanelIfNeeded() {
        if (panel == null) showPanel()
    }

    private fun removeBubble() {
        val view = bubble ?: return
        try { manager.removeView(view) } catch (_: Exception) { }
        bubble = null
        bubbleParams = null
    }

    private fun removePanel() {
        val view = panel ?: return
        try { manager.removeView(view) } catch (_: Exception) { }
        panel = null
        panelParams = null
        answerView = null
        userView = null
        statusView = null
        speakerButton = null
        micButton = null
        cameraButton = null
        screenButton = null
        panelOrbButton = null
    }

    private fun removeAll() {
        removePanel()
        removeBubble()
    }
}
