package com.allbat.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

/** Screen capture is only started after MediaProjection's Android-owned consent dialog succeeds. */
class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.allbat.assistant.action.START_SCREEN_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "allbat_screen_share"
        private const val NOTIFICATION_ID = 5201

        @Volatile var frameSink: ((String) -> Unit)? = null
        @Volatile var statusSink: ((Boolean) -> Unit)? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var captureWidth = 0
    private var captureHeight = 0
    private var densityDpi = 0
    private var stopping = false

    private val captureLoop = object : Runnable {
        override fun run() {
            if (stopping || projection == null) return
            captureOneFrame()
            handler.postDelayed(this, 1_300L)
        }
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopCapture(stopProjection = false)
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val command = intent
        if (command == null || command.action != ACTION_START) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }

            val resultCode = command.getIntExtra(EXTRA_RESULT_CODE, 0)
            val resultData = getResultData(command)
            if (resultCode != android.app.Activity.RESULT_OK || resultData == null) {
                stopSelf()
                return START_NOT_STICKY
            }

            // Android grants one projection session for each explicit system consent result.
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            val currentProjection = projection ?: run {
                stopSelf()
                return START_NOT_STICKY
            }
            currentProjection.registerCallback(projectionCallback, handler)
            startVirtualDisplay(currentProjection)
            stopping = false
            handler.removeCallbacks(captureLoop)
            handler.postDelayed(captureLoop, 800L)
            statusSink?.invoke(true)
        } catch (e: Exception) {
            statusSink?.invoke(false)
            stopCapture()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun getResultData(intent: Intent): Intent? = if (Build.VERSION.SDK_INT >= 33) {
        intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
    } else {
        intent.getParcelableExtra(EXTRA_RESULT_DATA)
    }

    @Suppress("DEPRECATION")
    private fun readDisplayMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = (getSystemService(Context.WINDOW_SERVICE) as WindowManager).currentWindowMetrics.bounds
            metrics.widthPixels = bounds.width()
            metrics.heightPixels = bounds.height()
            metrics.densityDpi = resources.displayMetrics.densityDpi
        } else {
            @Suppress("DEPRECATION")
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        }
        return metrics
    }

    private fun startVirtualDisplay(currentProjection: MediaProjection) {
        val metrics = readDisplayMetrics()
        captureWidth = max(1, metrics.widthPixels)
        captureHeight = max(1, metrics.heightPixels)
        densityDpi = max(1, metrics.densityDpi)
        imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = currentProjection.createVirtualDisplay(
            "AllBatScreenShare",
            captureWidth,
            captureHeight,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            handler
        )
    }

    private fun captureOneFrame() {
        val reader = imageReader ?: return
        var image: Image? = null
        var padded: Bitmap? = null
        var cropped: Bitmap? = null
        var scaled: Bitmap? = null
        try {
            image = reader.acquireLatestImage() ?: return
            val plane = image.planes.firstOrNull() ?: return
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            if (pixelStride <= 0 || rowStride < captureWidth * pixelStride) return
            val rowPadding = rowStride - pixelStride * captureWidth
            val paddedWidth = captureWidth + rowPadding / pixelStride
            padded = Bitmap.createBitmap(paddedWidth, captureHeight, Bitmap.Config.ARGB_8888)
            buffer.rewind()
            padded.copyPixelsFromBuffer(buffer)
            cropped = if (paddedWidth != captureWidth) Bitmap.createBitmap(padded, 0, 0, captureWidth, captureHeight) else padded
            val desiredWidth = min(720, captureWidth)
            val desiredHeight = max(1, (captureHeight.toFloat() * desiredWidth / captureWidth).toInt())
            scaled = if (cropped.width != desiredWidth || cropped.height != desiredHeight) {
                Bitmap.createScaledBitmap(cropped, desiredWidth, desiredHeight, true)
            } else cropped
            val output = ByteArrayOutputStream()
            if (!scaled.compress(Bitmap.CompressFormat.JPEG, 48, output)) return
            val encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
            frameSink?.invoke(encoded)
        } catch (_: Exception) {
            // A single dropped frame is non-fatal; the next timer tick retries.
        } finally {
            try { image?.close() } catch (_: Exception) {}
            try { if (scaled !== cropped && scaled !== padded) scaled?.recycle() } catch (_: Exception) {}
            try { if (cropped !== padded) cropped?.recycle() } catch (_: Exception) {}
            try { padded?.recycle() } catch (_: Exception) {}
        }
    }

    private fun stopCapture(stopProjection: Boolean = true) {
        stopping = true
        handler.removeCallbacks(captureLoop)
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        val oldProjection = projection
        projection = null
        if (stopProjection) {
            try { oldProjection?.unregisterCallback(projectionCallback) } catch (_: Exception) {}
            try { oldProjection?.stop() } catch (_: Exception) {}
        }
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        statusSink?.invoke(false)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 5202,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getActivity(
            this, 5203,
            Intent(this, MainActivity::class.java).setAction(MainActivity.ACTION_STOP_SCREEN)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_assistant)
            .setContentTitle("All Bat — اشتراک صفحه")
            .setContentText("اشتراک‌گذاری صفحه فعال است؛ برای توقف، دکمهٔ زیر را بزن.")
            .setContentIntent(openIntent)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_assistant, "توقف اشتراک صفحه", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "اشتراک‌گذاری صفحه", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "اعلان دائمی هنگام اشتراک صفحه با تأیید سیستم"
                    setShowBadge(false)
                }
            )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
