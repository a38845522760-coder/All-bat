package com.allbat.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Visible foreground service that keeps an explicitly started microphone/camera session eligible
 * to continue while the Activity is backgrounded. It does not start recording by itself. */
class SessionForegroundService : Service() {
    companion object {
        const val ACTION_START_VOICE = "com.allbat.assistant.action.START_VOICE"
        const val ACTION_STOP_VOICE = "com.allbat.assistant.action.STOP_VOICE"
        const val ACTION_START_CAMERA = "com.allbat.assistant.action.START_CAMERA"
        const val ACTION_STOP_CAMERA = "com.allbat.assistant.action.STOP_CAMERA"
        const val ACTION_STOP_ALL = "com.allbat.assistant.action.STOP_ALL"
        private const val CHANNEL_ID = "allbat_live_session"
        private const val NOTIFICATION_ID = 5101
    }

    private var voiceActive = false
    private var cameraActive = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_VOICE -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    voiceActive = true
                }
            }
            ACTION_STOP_VOICE -> voiceActive = false
            ACTION_START_CAMERA -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    cameraActive = true
                }
            }
            ACTION_STOP_CAMERA -> cameraActive = false
            ACTION_STOP_ALL -> {
                voiceActive = false
                cameraActive = false
            }
        }

        // A revoked permission must never leave a phantom foreground capture state.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            voiceActive = false
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraActive = false
        }

        if (!voiceActive && !cameraActive) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                var types = 0
                if (voiceActive) {
                    types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                }
                if (cameraActive) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                startForeground(NOTIFICATION_ID, notification, types)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: SecurityException) {
            voiceActive = false
            cameraActive = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val title = when {
            voiceActive && cameraActive -> "گفت‌وگوی زنده و دوربین فعال‌اند"
            voiceActive -> "گفت‌وگوی زنده فعال است"
            else -> "دوربین زنده فعال است"
        }
        val contentIntent = PendingIntent.getActivity(
            this, 5102,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getActivity(
            this, 5103,
            Intent(this, MainActivity::class.java)
                .setAction(MainActivity.ACTION_STOP_ALL)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_assistant)
            .setContentTitle("All Bat Assistant")
            .setContentText(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$title. برای قطع کامل صدا و تصویر، دکمهٔ پایان را بزن."))
            .setContentIntent(contentIntent)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_assistant, "پایان نشست", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "گفت‌وگوی دستیار", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "اعلان دائمی برای مکالمهٔ زندهٔ شروع‌شده توسط کاربر"
                    setShowBadge(false)
                }
            )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        voiceActive = false
        cameraActive = false
        super.onDestroy()
    }
}
