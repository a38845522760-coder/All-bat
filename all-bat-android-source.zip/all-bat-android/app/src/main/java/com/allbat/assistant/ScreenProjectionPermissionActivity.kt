package com.allbat.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.core.content.ContextCompat.startForegroundService

/** Small transparent activity used only to display Android's mandatory MediaProjection consent UI. */
class ScreenProjectionPermissionActivity : Activity() {
    companion object {
        private const val REQUEST_SCREEN_CAPTURE = 7310
        @Volatile var resultSink: ((Boolean) -> Unit)? = null
    }

    private var captureRequestStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        publishPermissionSurfaceVisibility(true)
        if (savedInstanceState?.getBoolean("capture_request_started") == true) {
            captureRequestStarted = true
            return
        }
        // Notification permission is optional; it must not add a second dialog or block capture.
        requestCaptureConsent()
    }

    private fun publishPermissionSurfaceVisibility(visible: Boolean) {
        getSharedPreferences("allbat_session_state", Context.MODE_PRIVATE).edit()
            .putBoolean("permission_surface_visible", visible)
            .apply()
        try {
            sendBroadcast(Intent(SessionForegroundService.ACTION_SURFACE_VISIBILITY).setPackage(packageName).apply {
                putExtra(SessionForegroundService.EXTRA_SURFACE_OWNER, "permission")
                putExtra(SessionForegroundService.EXTRA_SURFACE_VISIBLE, visible)
            })
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        publishPermissionSurfaceVisibility(false)
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("capture_request_started", captureRequestStarted)
        super.onSaveInstanceState(outState)
    }

    private fun requestCaptureConsent() {
        if (captureRequestStarted) return
        captureRequestStarted = true
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE)
        } catch (error: Exception) {
            publishPermissionSurfaceVisibility(false)
            resultSink?.invoke(false)
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_SCREEN_CAPTURE) return
        publishPermissionSurfaceVisibility(false)
        if (resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            try {
                startForegroundService(this, serviceIntent)
            } catch (_: Exception) {
                stopService(Intent(this, ScreenCaptureService::class.java))
                resultSink?.invoke(false)
            }
        } else {
            resultSink?.invoke(false)
        }
        finish()
    }
}
