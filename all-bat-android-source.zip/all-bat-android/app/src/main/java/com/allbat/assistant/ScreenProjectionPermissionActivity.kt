package com.allbat.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import android.Manifest
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startForegroundService

/** Small transparent activity used only to display Android's mandatory MediaProjection consent UI. */
class ScreenProjectionPermissionActivity : Activity() {
    companion object {
        private const val REQUEST_SCREEN_CAPTURE = 7310
        private const val REQUEST_NOTIFICATIONS = 7311
        @Volatile var resultSink: ((Boolean) -> Unit)? = null
    }

    private var captureRequestStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState?.getBoolean("capture_request_started") == true) {
            captureRequestStarted = true
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        } else {
            requestCaptureConsent()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("capture_request_started", captureRequestStarted)
        super.onSaveInstanceState(outState)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICATIONS) {
            // Continue even if notifications are denied; Android still owns the capture consent.
            requestCaptureConsent()
        }
    }

    private fun requestCaptureConsent() {
        if (captureRequestStarted) return
        captureRequestStarted = true
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE)
        } catch (_: Exception) {
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_SCREEN_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            try {
                startForegroundService(this, serviceIntent)
            } catch (_: Exception) {
                stopService(Intent(this, ScreenCaptureService::class.java))
                resultSink?.invoke(false)
            }
        } else {
            resultSink?.invoke(false)
        }
        finish()
    }
}
