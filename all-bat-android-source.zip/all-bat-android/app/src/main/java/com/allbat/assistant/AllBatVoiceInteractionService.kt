package com.allbat.assistant

import android.service.voice.VoiceInteractionService

/** Android system entry point for a user-selected default assistant. */
class AllBatVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
    }
}
