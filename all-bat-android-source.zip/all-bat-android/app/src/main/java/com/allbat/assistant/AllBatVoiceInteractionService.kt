package com.allbat.assistant

import android.service.voice.VoiceInteractionService

/** System entry point for launching All Bat through Android's selected-assistant flow. */
class AllBatVoiceInteractionService : VoiceInteractionService()
