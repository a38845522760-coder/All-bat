package com.allbat.assistant

import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionSession

class AllBatVoiceInteractionSession(context: android.content.Context) : VoiceInteractionSession(context) {
    private val appContext = context
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val intent = Intent(appContext, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("launched_from_assistant_role", true)
        }
        try {
            startVoiceActivity(intent)
        } catch (_: Exception) {
            appContext.startActivity(intent)
        }
        hide()
    }
}
