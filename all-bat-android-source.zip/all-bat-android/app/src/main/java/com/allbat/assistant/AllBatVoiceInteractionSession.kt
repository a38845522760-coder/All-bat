package com.allbat.assistant

import android.Manifest
import android.os.Build
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.Window
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.min

/**
 * Text-first assistant surface. The system screenshot is supplied by VoiceInteractionSession;
 * it is never started through MediaProjection and is never sent whole to the model. The user
 * chooses a rectangle in the web UI, and only that cropped image is attached to the draft.
 */
class AllBatVoiceInteractionSession(context: Context) : android.service.voice.VoiceInteractionSession(context) {
    companion object {
        const val ACTION_OVERLAY_MIC = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_TOGGLE_MIC"
        const val ACTION_OVERLAY_CAMERA = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_TOGGLE_CAMERA"
        const val ACTION_OVERLAY_SCREEN = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_TOGGLE_SCREEN"
        const val ACTION_OVERLAY_END = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_END_SESSION"
    }

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var assistantWebView: WebView? = null
    private var pageLoaded = false
    private var visible = false
    private var stopRequestedByUser = false
    private var sessionVoiceServiceStarted = false
    private var sessionCameraServiceStarted = false
    private var previousAudioMode: Int? = null
    private var voiceAudioFocusRequest: AudioFocusRequest? = null
    private val voiceAudioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { _ -> /* Keep duplex Live audio active; Chromium owns the stream lifecycle. */ }
    private var pendingScreenshotDataUrl: String? = null
    private var overlayReceiverRegistered = false

    private val sessionOverlayReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val script = when (intent?.action) {
                ACTION_OVERLAY_MIC -> "window.__allbatToggleMicrophone && window.__allbatToggleMicrophone();"
                ACTION_OVERLAY_CAMERA -> "window.__allbatToggleCamera && window.__allbatToggleCamera();"
                ACTION_OVERLAY_SCREEN -> "window.__allbatToggleScreen && window.__allbatToggleScreen();"
                ACTION_OVERLAY_END -> {
                    stopRequestedByUser = true
                    "window.__assistantNativeStopAll && window.__assistantNativeStopAll();"
                }
                else -> return
            }
            evaluate(script)
            if (intent?.action == ACTION_OVERLAY_END) {
                try { appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_ALL)) } catch (_: Exception) { }
            }
        }
    }

    private fun registerSessionOverlayReceiver() {
        if (overlayReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(ACTION_OVERLAY_MIC)
            addAction(ACTION_OVERLAY_CAMERA)
            addAction(ACTION_OVERLAY_SCREEN)
            addAction(ACTION_OVERLAY_END)
        }
        try {
            ContextCompat.registerReceiver(appContext, sessionOverlayReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            overlayReceiverRegistered = true
        } catch (error: Exception) {
            android.util.Log.w("AllBatOverlay", "Could not register system-assistant overlay controls", error)
        }
    }

    override fun onCreateContentView(): View {
        registerSessionOverlayReceiver()
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.WHITE, Color.rgb(248, 251, 255))
            ).apply {
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), Color.rgb(220, 230, 246))
            }
            clipToOutline = true
            elevation = dp(12).toFloat()
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(6), dp(12), dp(6))
            setBackgroundColor(Color.TRANSPARENT)
        }
        val orb = TextView(context).apply {
            text = ""
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.WHITE, Color.rgb(219, 233, 255), Color.rgb(76, 137, 255))
            ).apply { shape = GradientDrawable.OVAL }
            elevation = dp(4).toFloat()
        }
        header.addView(orb, LinearLayout.LayoutParams(dp(31), dp(31)).apply { marginEnd = dp(9) })
        val brand = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(context).apply {
            text = "Digi"
            setTextColor(Color.rgb(19, 29, 48))
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        }
        brand.addView(title)
        val subtitle = TextView(context).apply {
            text = "دستیار هوشمند"
            setTextColor(Color.rgb(104, 116, 139))
            textSize = 10f
        }
        brand.addView(subtitle)
        header.addView(brand, LinearLayout.LayoutParams(0, dp(40), 1f))
        val minimise = Button(context).apply {
            text = "Minimize"
            isAllCaps = false
            textSize = 12f
            setTextColor(Color.rgb(37, 75, 143))
            background = GradientDrawable().apply {
                cornerRadius = dp(99).toFloat()
                setColor(Color.rgb(232, 241, 255))
            }
            setOnClickListener { hide() }
        }
        header.addView(minimise, LinearLayout.LayoutParams(dp(91), dp(38)).apply { marginEnd = dp(6) })
        val close = Button(context).apply {
            text = "✕"
            isAllCaps = false
            textSize = 17f
            setTextColor(Color.rgb(167, 45, 62))
            background = GradientDrawable().apply {
                cornerRadius = dp(99).toFloat()
                setColor(Color.rgb(255, 234, 238))
            }
            contentDescription = "پایان دستیار"
            setOnClickListener {
                stopRequestedByUser = true
                evaluate("window.__assistantNativeStopAll && window.__assistantNativeStopAll();")
                try { appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_ALL)) } catch (_: Exception) { }
                mainHandler.postDelayed({ hide() }, 180L)
            }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(38), dp(38)))
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(57)))

        val web = WebView(context).apply {
            setBackgroundColor(Color.rgb(249, 251, 255))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                allowFileAccess = false
                allowContentAccess = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                safeBrowsingEnabled = true
                loadsImagesAutomatically = true
            }
            addJavascriptInterface(SessionBridge(), "AndroidAssistant")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    mainHandler.post {
                        val origin = request.origin
                        if (!origin.scheme.equals("https", true) || !origin.host.equals(BuildConfig.SPACE_HOST, true)) {
                            request.deny()
                            return@post
                        }
                        val allowed = request.resources.filter { resource ->
                            when (resource) {
                                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                                else -> false
                            }
                        }.toTypedArray()
                        if (allowed.isNotEmpty()) request.grant(allowed) else request.deny()
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.scheme.equals("https", true) && uri.host.equals(BuildConfig.SPACE_HOST, true)) return false
                    if (uri.scheme.equals("about", true) || uri.scheme.equals("blob", true) || uri.scheme.equals("data", true)) return false
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pageLoaded = true
                    evaluate("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);")
                    deliverPendingScreenshot()
                }
            }
        }
        assistantWebView = web
        ScreenCaptureService.frameSink = { frame ->
            mainHandler.post {
                if (pageLoaded && assistantWebView != null) {
                    assistantWebView?.evaluateJavascript(
                        "window.__assistantNativeFrame && window.__assistantNativeFrame(${JSONObject.quote(frame)});",
                        null
                    )
                }
            }
        }
        ScreenCaptureService.statusSink = { active ->
            mainHandler.post {
                if (assistantWebView != null) {
                    val function = if (active) "__assistantNativeScreenStarted" else "__assistantNativeScreenStopped"
                    assistantWebView?.evaluateJavascript("window.$function && window.$function();", null)
                }
            }
        }
        ScreenProjectionPermissionActivity.resultSink = { granted ->
            if (!granted) evaluate("window.__assistantNativeScreenDenied && window.__assistantNativeScreenDenied();")
        }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        try {
            val html = appContext.assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            web.loadDataWithBaseURL(BuildConfig.SPACE_BASE_URL, html, "text/html", "UTF-8", null)
        } catch (error: Exception) {
            val safeError = error.javaClass.simpleName
            web.loadDataWithBaseURL(
                BuildConfig.SPACE_BASE_URL,
                "<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><body style='font-family:system-ui;padding:24px'><h3>رابط دستیار بارگذاری نشد</h3><p>ساخت برنامه را بررسی کن.</p><code>$safeError</code></body></html>",
                "text/html", "UTF-8", null
            )
        }
        return root
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        visible = true
        assistantWebView?.onResume()
        try {
            val activityWindow: Window? = window?.window
            activityWindow?.setBackgroundDrawableResource(android.R.color.transparent)
            val availableDp = context.resources.configuration.screenHeightDp.coerceAtLeast(460)
            val sheetDp = min(availableDp - 18, 590).coerceAtLeast(430)
            activityWindow?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, dp(sheetDp))
            activityWindow?.setGravity(Gravity.BOTTOM)
            val windowParams = activityWindow?.attributes
            if (windowParams != null) {
                windowParams.gravity = Gravity.BOTTOM
                windowParams.dimAmount = 0.12f
                windowParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                activityWindow.attributes = windowParams
            }
        } catch (_: Exception) { }
        stopRequestedByUser = false
        evaluate("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);")
        try { appContext.sendBroadcast(Intent(SessionForegroundService.ACTION_REFRESH_OVERLAY).setPackage(appContext.packageName)) } catch (_: Exception) { }
        deliverPendingScreenshot()
    }

    override fun onHandleScreenshot(screenshot: Bitmap?) {
        if (screenshot == null) {
            pendingScreenshotDataUrl = null
            evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
            return
        }
        try {
            pendingScreenshotDataUrl = encodeScreenshot(screenshot)
            deliverPendingScreenshot()
        } catch (error: Exception) {
            pendingScreenshotDataUrl = null
            android.util.Log.w("AllBatAssistant", "Could not prepare assistant screenshot", error)
            evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
        }
    }

    private fun encodeScreenshot(source: Bitmap): String {
        var resized: Bitmap? = null
        val bitmap: Bitmap
        val ratio = min(1f, 1600f / source.width.toFloat())
        if (ratio < 1f) {
            resized = Bitmap.createScaledBitmap(source, maxOf(1, (source.width * ratio).toInt()), maxOf(1, (source.height * ratio).toInt()), true)
            bitmap = resized
        } else {
            bitmap = source
        }
        val out = ByteArrayOutputStream()
        try {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 68, out)) throw IllegalStateException("JPEG encoding failed")
            return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } finally {
            if (resized != null && resized !== source) resized.recycle()
            try { out.close() } catch (_: Exception) { }
        }
    }

    private fun deliverPendingScreenshot() {
        if (!pageLoaded || !visible) return
        val data = pendingScreenshotDataUrl ?: return
        evaluate("window.__allbatAssistantSetScreenshot && window.__allbatAssistantSetScreenshot(${JSONObject.quote(data)});")
    }

    private fun evaluate(script: String) {
        mainHandler.post { assistantWebView?.evaluateJavascript(script, null) }
    }

    private fun prepareCommunicationAudio() {
        val manager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (previousAudioMode == null) previousAudioMode = manager.mode
            manager.mode = AudioManager.MODE_IN_COMMUNICATION
        } catch (error: Exception) {
            android.util.Log.w("AllBatAudio", "Could not set communication mode for assistant session", error)
        }
        try {
            val request = voiceAudioFocusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener(voiceAudioFocusChangeListener)
                .build()
                .also { voiceAudioFocusRequest = it }
            manager.requestAudioFocus(request)
        } catch (error: Exception) {
            android.util.Log.w("AllBatAudio", "Could not acquire assistant-session audio focus", error)
        }
    }

    private fun restoreCommunicationAudio() {
        val manager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try { voiceAudioFocusRequest?.let { manager.abandonAudioFocusRequest(it) } } catch (_: Exception) { }
        voiceAudioFocusRequest = null
        val mode = previousAudioMode
        if (mode != null) {
            try { manager.mode = mode } catch (_: Exception) { }
            previousAudioMode = null
        }
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    override fun onHide() {
        visible = false
        // Hiding/minimizing the system assistant is not an implicit hang-up. The user can keep
        // Live running under its foreground notification and floating orb; the explicit X control
        // calls __assistantNativeStopAll before hiding this window.
        super.onHide()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            hide()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        visible = false
        try { if (overlayReceiverRegistered) appContext.unregisterReceiver(sessionOverlayReceiver) } catch (_: Exception) { }
        overlayReceiverRegistered = false
        if (sessionVoiceServiceStarted || sessionCameraServiceStarted || stopRequestedByUser) {
            try { appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_ALL)) } catch (_: Exception) { }
        }
        sessionVoiceServiceStarted = false
        sessionCameraServiceStarted = false
        restoreCommunicationAudio()
        ScreenCaptureService.frameSink = null
        ScreenCaptureService.statusSink = null
        ScreenProjectionPermissionActivity.resultSink = null
        assistantWebView?.apply {
            removeJavascriptInterface("AndroidAssistant")
            stopLoading()
            destroy()
        }
        assistantWebView = null
        super.onDestroy()
    }

    inner class SessionBridge {
        @android.webkit.JavascriptInterface
        fun selectScreenRegion() {
            mainHandler.post {
                if (pendingScreenshotDataUrl.isNullOrEmpty()) {
                    evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
                } else {
                    evaluate("window.__allbatAssistantStartRegionSelection && window.__allbatAssistantStartRegionSelection();")
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun startScreenShare() {
            mainHandler.post {
                try {
                    val request = Intent(appContext, ScreenProjectionPermissionActivity::class.java)
                    if (Build.VERSION.SDK_INT >= 34) startAssistantActivity(request, Bundle.EMPTY)
                    else appContext.startActivity(request.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (error: Exception) {
                    Toast.makeText(appContext, "بازکردن مجوز اشتراک صفحه ممکن نشد", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopScreenShare() {
            mainHandler.post { appContext.stopService(Intent(appContext, ScreenCaptureService::class.java)) }
        }

        @android.webkit.JavascriptInterface
        fun requestDefaultAssistant() {
            mainHandler.post {
                Toast.makeText(appContext, "برای تغییر دستیار پیش‌فرض، برنامه را از صفحهٔ اصلی باز کن", Toast.LENGTH_SHORT).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun isDefaultAssistant(): Boolean = true

        @android.webkit.JavascriptInterface
        fun isAssistantSession(): Boolean = true

        @android.webkit.JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME

        // The microphone is enabled only when the user explicitly presses Live in the assistant.
        @android.webkit.JavascriptInterface
        fun prepareAudioSession() {
            mainHandler.post { prepareCommunicationAudio() }
        }

        @android.webkit.JavascriptInterface
        fun cancelAudioSession() {
            mainHandler.post { restoreCommunicationAudio() }
        }

        @android.webkit.JavascriptInterface
        fun startVoiceSession() {
            mainHandler.post {
                if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(appContext, "ابتدا برنامه را باز کن و مجوز میکروفون را بده.", Toast.LENGTH_LONG).show()
                    return@post
                }
                try {
                    prepareCommunicationAudio()
                    ContextCompat.startForegroundService(
                        appContext,
                        Intent(appContext, SessionForegroundService::class.java)
                            .setAction(SessionForegroundService.ACTION_START_VOICE)
                            .putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "system_assistant")
                    )
                    sessionVoiceServiceStarted = true
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(appContext)) {
                        // This is deliberately user-triggered (the user pressed Live). Android
                        // requires its own permission screen before the orb can float over apps.
                        mainHandler.postDelayed({ requestFloatingAssistantOverlay() }, 450L)
                    }
                } catch (error: Exception) {
                    Toast.makeText(appContext, "شروع نشست صوتی ممکن نشد", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopVoiceSession() {
            mainHandler.post {
                sessionVoiceServiceStarted = false
                appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_VOICE))
                restoreCommunicationAudio()
            }
        }

        @android.webkit.JavascriptInterface
        fun startCameraSession() {
            mainHandler.post {
                if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(appContext, "برای روشن‌کردن دوربین، ابتدا برنامه را باز و مجوز دوربین را تأیید کن.", Toast.LENGTH_LONG).show()
                    return@post
                }
                try {
                    ContextCompat.startForegroundService(
                        appContext,
                        Intent(appContext, SessionForegroundService::class.java)
                            .setAction(SessionForegroundService.ACTION_START_CAMERA)
                            .putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "system_assistant")
                    )
                    sessionCameraServiceStarted = true
                } catch (_: Exception) { }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopCameraSession() {
            mainHandler.post {
                sessionCameraServiceStarted = false
                appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_CAMERA))
            }
        }

        @android.webkit.JavascriptInterface
        fun updateAssistantOverlay(
            userText: String?, answerText: String?, status: String?, generating: Boolean,
            micMuted: Boolean, cameraActive: Boolean, screenActive: Boolean
        ) {
            val update = Intent(SessionForegroundService.ACTION_UPDATE_OVERLAY).setPackage(appContext.packageName).apply {
                putExtra(SessionForegroundService.EXTRA_USER_TEXT, userText.orEmpty().take(600))
                putExtra(SessionForegroundService.EXTRA_ANSWER_TEXT, answerText.orEmpty().take(3000))
                putExtra(SessionForegroundService.EXTRA_STATUS, status.orEmpty().take(100))
                putExtra(SessionForegroundService.EXTRA_GENERATING, generating)
                putExtra(SessionForegroundService.EXTRA_MIC_MUTED, micMuted)
                putExtra(SessionForegroundService.EXTRA_CAMERA_ACTIVE, cameraActive)
                putExtra(SessionForegroundService.EXTRA_SCREEN_ACTIVE, screenActive)
                putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "system_assistant")
            }
            try { appContext.sendBroadcast(update) } catch (_: Exception) { }
        }

        @android.webkit.JavascriptInterface
        fun hasFloatingAssistantOverlayPermission(): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M || android.provider.Settings.canDrawOverlays(appContext)

        @android.webkit.JavascriptInterface
        fun requestFloatingAssistantOverlay() {
            mainHandler.post {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || android.provider.Settings.canDrawOverlays(appContext)) {
                    try { appContext.sendBroadcast(Intent(SessionForegroundService.ACTION_REFRESH_OVERLAY).setPackage(appContext.packageName)) } catch (_: Exception) { }
                    return@post
                }
                try {
                    appContext.startActivity(
                        Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${appContext.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                    Toast.makeText(appContext, "تنظیم حباب شناور در دسترس نیست", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @android.webkit.JavascriptInterface fun markNextFileChooserAsCamera() = Unit
    }
}
