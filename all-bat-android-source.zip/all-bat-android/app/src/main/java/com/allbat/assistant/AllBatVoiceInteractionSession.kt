package com.allbat.assistant

import android.Manifest
import android.os.Build
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.min

/**
 * Text-first assistant surface. The system screenshot is supplied by VoiceInteractionSession;
 * it is never started through MediaProjection and is never sent whole to the model. The user
 * chooses a rectangle in the web UI, and only that cropped image is attached to the draft.
 */
class AllBatVoiceInteractionSession(context: Context) : android.service.voice.VoiceInteractionSession(context) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var assistantWebView: WebView? = null
    private var pageLoaded = false
    private var visible = false
    private var pendingScreenshotDataUrl: String? = null

    override fun onCreateContentView(): View {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 248, 252))
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(20, 28, 48))
        }
        val title = TextView(context).apply {
            text = "All Bat  ·  دستیار متنی"
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(40), 1f))
        val close = Button(context).apply {
            text = "بستن"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(53, 64, 88))
            setOnClickListener { hide() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(72), dp(40)))
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        val web = WebView(context).apply {
            setBackgroundColor(Color.rgb(246, 248, 252))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                allowFileAccess = false
                allowContentAccess = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                safeBrowsingEnabled = true
                loadsImagesAutomatically = true
            }
            addJavascriptInterface(SessionBridge(), "AndroidAssistant")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    mainHandler.post {
                        val origin = request.origin
                        if (!origin.scheme.equals("https", true) || !origin.host.equals(BuildConfig.SPACE_HOST, true)) {
                            request.deny()
                            return@post
                        }
                        val allowed = request.resources.filter { resource ->
                            when (resource) {
                                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                                else -> false
                            }
                        }.toTypedArray()
                        if (allowed.isNotEmpty()) request.grant(allowed) else request.deny()
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.scheme.equals("https", true) && uri.host.equals(BuildConfig.SPACE_HOST, true)) return false
                    if (uri.scheme.equals("about", true) || uri.scheme.equals("blob", true) || uri.scheme.equals("data", true)) return false
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pageLoaded = true
                    evaluate("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);")
                    deliverPendingScreenshot()
                }
            }
        }
        assistantWebView = web
        ScreenCaptureService.frameSink = { frame ->
            mainHandler.post {
                if (visible && pageLoaded && assistantWebView != null) {
                    assistantWebView?.evaluateJavascript(
                        "window.__assistantNativeFrame && window.__assistantNativeFrame(${JSONObject.quote(frame)});",
                        null
                    )
                }
            }
        }
        ScreenCaptureService.statusSink = { active ->
            mainHandler.post {
                if (assistantWebView != null) {
                    val function = if (active) "__assistantNativeScreenStarted" else "__assistantNativeScreenStopped"
                    assistantWebView?.evaluateJavascript("window.$function && window.$function();", null)
                }
            }
        }
        ScreenProjectionPermissionActivity.resultSink = { granted ->
            if (!granted) evaluate("window.__assistantNativeScreenDenied && window.__assistantNativeScreenDenied();")
        }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        try {
            val html = appContext.assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            web.loadDataWithBaseURL(BuildConfig.SPACE_BASE_URL, html, "text/html", "UTF-8", null)
        } catch (error: Exception) {
            val safeError = error.javaClass.simpleName
            web.loadDataWithBaseURL(
                BuildConfig.SPACE_BASE_URL,
                "<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><body style='font-family:system-ui;padding:24px'><h3>رابط دستیار بارگذاری نشد</h3><p>ساخت برنامه را بررسی کن.</p><code>$safeError</code></body></html>",
                "text/html", "UTF-8", null
            )
        }
        return root
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        visible = true
        assistantWebView?.onResume()
        try {
            window?.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        } catch (_: Exception) { }
        evaluate("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);")
        deliverPendingScreenshot()
    }

    override fun onHandleScreenshot(screenshot: Bitmap?) {
        if (screenshot == null) {
            pendingScreenshotDataUrl = null
            evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
            return
        }
        try {
            pendingScreenshotDataUrl = encodeScreenshot(screenshot)
            deliverPendingScreenshot()
        } catch (error: Exception) {
            pendingScreenshotDataUrl = null
            android.util.Log.w("AllBatAssistant", "Could not prepare assistant screenshot", error)
            evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
        }
    }

    private fun encodeScreenshot(source: Bitmap): String {
        var resized: Bitmap? = null
        val bitmap: Bitmap
        val ratio = min(1f, 1600f / source.width.toFloat())
        if (ratio < 1f) {
            resized = Bitmap.createScaledBitmap(source, maxOf(1, (source.width * ratio).toInt()), maxOf(1, (source.height * ratio).toInt()), true)
            bitmap = resized
        } else {
            bitmap = source
        }
        val out = ByteArrayOutputStream()
        try {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 68, out)) throw IllegalStateException("JPEG encoding failed")
            return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } finally {
            if (resized != null && resized !== source) resized.recycle()
            try { out.close() } catch (_: Exception) { }
        }
    }

    private fun deliverPendingScreenshot() {
        if (!pageLoaded || !visible) return
        val data = pendingScreenshotDataUrl ?: return
        evaluate("window.__allbatAssistantSetScreenshot && window.__allbatAssistantSetScreenshot(${JSONObject.quote(data)});")
    }

    private fun evaluate(script: String) {
        mainHandler.post { assistantWebView?.evaluateJavascript(script, null) }
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    override fun onHide() {
        visible = false
        evaluate("window.__assistantNativeStopAll && window.__assistantNativeStopAll();")
        assistantWebView?.onPause()
        super.onHide()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            hide()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        visible = false
        ScreenCaptureService.frameSink = null
        ScreenCaptureService.statusSink = null
        ScreenProjectionPermissionActivity.resultSink = null
        assistantWebView?.apply {
            removeJavascriptInterface("AndroidAssistant")
            stopLoading()
            destroy()
        }
        assistantWebView = null
        super.onDestroy()
    }

    inner class SessionBridge {
        @android.webkit.JavascriptInterface
        fun selectScreenRegion() {
            mainHandler.post {
                if (pendingScreenshotDataUrl.isNullOrEmpty()) {
                    evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
                } else {
                    evaluate("window.__allbatAssistantStartRegionSelection && window.__allbatAssistantStartRegionSelection();")
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun startScreenShare() {
            mainHandler.post {
                try {
                    val request = Intent(appContext, ScreenProjectionPermissionActivity::class.java)
                    if (Build.VERSION.SDK_INT >= 34) startAssistantActivity(request, Bundle.EMPTY)
                    else appContext.startActivity(request.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (error: Exception) {
                    Toast.makeText(appContext, "بازکردن مجوز اشتراک صفحه ممکن نشد", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopScreenShare() {
            mainHandler.post { appContext.stopService(Intent(appContext, ScreenCaptureService::class.java)) }
        }

        @android.webkit.JavascriptInterface
        fun requestDefaultAssistant() {
            mainHandler.post {
                Toast.makeText(appContext, "برای تغییر دستیار پیش‌فرض، برنامه را از صفحهٔ اصلی باز کن", Toast.LENGTH_SHORT).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun isDefaultAssistant(): Boolean = true

        @android.webkit.JavascriptInterface
        fun isAssistantSession(): Boolean = true

        @android.webkit.JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME

        // A text-first assistant panel never enables the microphone automatically.
        @android.webkit.JavascriptInterface fun prepareAudioSession() = Unit
        @android.webkit.JavascriptInterface fun cancelAudioSession() = Unit
        @android.webkit.JavascriptInterface fun startVoiceSession() = Unit
        @android.webkit.JavascriptInterface fun stopVoiceSession() = Unit
        @android.webkit.JavascriptInterface fun startCameraSession() = Unit
        @android.webkit.JavascriptInterface fun stopCameraSession() = Unit
        @android.webkit.JavascriptInterface fun markNextFileChooserAsCamera() = Unit
    }
}
