package com.allbat.assistant

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.TimeUnit

/** Bridges Android permission UI back to the waiting WebView function-call response. */
internal object DeviceToolAwaiter {
    private data class Pending(
        val latch: CountDownLatch = CountDownLatch(1),
        val completed: AtomicBoolean = AtomicBoolean(false),
        @Volatile var result: String? = null
    )
    private val pending = ConcurrentHashMap<String, Pending>()

    fun create(): String {
        val id = UUID.randomUUID().toString().replace("-", "")
        pending[id] = Pending()
        return id
    }

    fun isPending(id: String?): Boolean = !id.isNullOrBlank() && pending.containsKey(id)

    fun complete(id: String?, result: String) {
        if (id.isNullOrBlank()) return
        val item = pending[id] ?: return
        // A permission callback, timeout cancellation, and Activity.onDestroy may
        // race. Only the first terminal result is authoritative.
        if (!item.completed.compareAndSet(false, true)) return
        item.result = result
        item.latch.countDown()
    }

    fun await(id: String, timeoutSeconds: Long = 45): String {
        val item = pending[id] ?: return "{\"ok\":false,\"message\":\"درخواست ابزار پیدا نشد.\"}"
        return try {
            if (item.latch.await(timeoutSeconds, TimeUnit.SECONDS)) item.result
                ?: "{\"ok\":false,\"message\":\"نتیجهٔ ابزار خالی است.\"}"
            else "{\"ok\":false,\"message\":\"زمان تأیید مجوز تمام شد؛ فرمان را دوباره بگو.\"}"
        } finally { pending.remove(id) }
    }
}
