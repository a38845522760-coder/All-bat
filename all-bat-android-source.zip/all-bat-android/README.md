# All Bat Android — version 1.1.0

This bundle is the Android-native wrapper for the existing All Bat / Gemini web experience. It keeps the model API credentials on the server; no API key is embedded in the Android source.

## What changed in 1.1.0

- Fixed the Kotlin compilation failures found in GitHub Actions: `MediaProjectionManager` now uses `android.media.projection`, and `RecognitionService.Callback` is no longer called through the unsupported `event` method.
- The Home/default-assistant entry point no longer starts microphone/Live automatically. It opens a text-first assistant panel and requests a system-provided screenshot when Android supplies one.
- In the Home assistant panel, the user can draw a rectangle on the screenshot. Only that rectangle is cropped and attached to the message draft; the original full screenshot is not attached or sent by the region-selection path.
- In the normal app's active Gemini Live conversation, the existing screen-share control continues to send complete screen frames through Android MediaProjection after the Android consent dialog.
- Added a consent activity for starting MediaProjection from the assistant panel and kept the foreground notification path explicit.
- Restored the normal app's screen-frame callback when it returns to the foreground after an assistant session.
- Increased the app version to 1.1.0.

## Build through the repository workflow

The repository workflow expects this archive to be located at the repository root as `all-bat-android-source.zip`. Upload/replace that ZIP on the `main` branch to trigger the workflow. After a successful run, open **Actions → Build All Bat APK → Artifacts** and download `all-bat-debug-apk`.

## Important Android behavior

- Android controls whether the assistant session receives a screenshot. Secure windows, user privacy settings, device policy, or unsupported system behavior may result in no screenshot. In that case the UI reports that the screenshot is unavailable and does not substitute a full-screen capture.
- Android requires user approval for every MediaProjection session. Screen sharing cannot start silently.
- Camera, microphone, assistant-role, and notification permissions are governed by Android. The Home assistant panel does not start the microphone automatically.
- Actual APK compilation and device runtime behavior must be confirmed by the repository's GitHub Actions run and then tested on the target phone.
