#!/usr/bin/env python3
"""Fetch the public AI Bale UI from Hugging Face and inject the Android bridge."""
from __future__ import annotations

import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSET_DIR = ROOT / "app" / "src" / "main" / "assets"
OUTPUT = ASSET_DIR / "index.html"
BRIDGE = ASSET_DIR / "native-bridge.js"
FEEDBACK_WIDGET = ASSET_DIR / "fb-widget.js"
FEEDBACK_SOURCE_URL = os.environ.get(
    "ALLBAT_FEEDBACK_SOURCE_URL",
    "https://huggingface.co/spaces/Mohamad1039/Bot.gemini/resolve/main/mini_feedback.py?download=true",
)
DEFAULT_SOURCE_URL = (
    "https://huggingface.co/spaces/Mohamad1039/Bot.gemini/resolve/main/index.html"
    "?download=true"
)
SOURCE_URL = os.environ.get("ALLBAT_HTML_SOURCE_URL", DEFAULT_SOURCE_URL)
MAX_HTML_BYTES = 5 * 1024 * 1024


def load_feedback_widget() -> str:
    """The Space injects the 👍/👎 voting widget only when it serves the page itself, so the app has to bundle it.

    Prefer the newest widget text from the Space's mini_feedback.py; fall back to the copy kept in assets/.
    """
    try:
        request = urllib.request.Request(FEEDBACK_SOURCE_URL, headers={"User-Agent": "AllBatAndroidBuilder/1.0"})
        with urllib.request.urlopen(request, timeout=30) as response:
            source = response.read(2 * 1024 * 1024).decode("utf-8-sig")
        match = re.search(r'WIDGET_JS\s*=\s*r"""(.*?)"""', source, flags=re.DOTALL)
        if match and "/api/feedback" in match.group(1) and "__fbWidget" in match.group(1):
            print("Voting widget: using the latest version from the Space")
            return match.group(1)
    except Exception as exc:  # network, decoding or format problems must never break the build
        print(f"Voting widget: Space copy unavailable ({exc}); using the bundled copy")
    return FEEDBACK_WIDGET.read_text(encoding="utf-8")


ALLOWED_HOSTS = {h.strip().lower() for h in os.environ.get("ALLBAT_ALLOWED_HOSTS", "").split(",") if h.strip()}
SOURCE_TAG = re.compile(r"<(script|iframe|frame|embed|object|link)\b[^>]*?\b(?:src|href|data)\s*=\s*[\"']?(https?:)?//([^/\"'\s>]+)", re.IGNORECASE)


def audit_remote_content(html: str) -> None:
    """The bridged WebView exposes phone tools (calls, SMS, screen control) to whatever page it runs.
    So every script/frame that the downloaded UI pulls from another host is a supply-chain risk: list them,
    and fail the build when ALLBAT_STRICT_HTML=1 and a host is not in ALLBAT_ALLOWED_HOSTS."""
    import hashlib

    print("UI source SHA-256:", hashlib.sha256(html.encode("utf-8")).hexdigest())
    hosts: dict[str, set[str]] = {}
    for tag, _scheme, host in SOURCE_TAG.findall(html):
        hosts.setdefault(host.lower(), set()).add(tag.lower())
    unknown = {h: t for h, t in hosts.items() if h not in ALLOWED_HOSTS}
    for host, tags in sorted(unknown.items()):
        print(f"WARNING: UI loads {', '.join(sorted(tags))} from external host {host}")
    if unknown and os.environ.get("ALLBAT_STRICT_HTML") == "1":
        print("Strict mode: refusing to package a UI that loads code from unlisted hosts.", file=sys.stderr)
        raise SystemExit(9)


def main() -> int:
    if not BRIDGE.is_file():
        print(f"Missing bridge file: {BRIDGE}", file=sys.stderr)
        return 2

    request = urllib.request.Request(
        SOURCE_URL,
        headers={"User-Agent": "AllBatAndroidBuilder/1.0", "Accept": "text/html,*/*;q=0.8"},
    )
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            final_url = response.geturl()
            raw = response.read(MAX_HTML_BYTES + 1)
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        print(f"Could not fetch the public Hugging Face UI: {exc}", file=sys.stderr)
        print("Check the Space's public access and network availability, then retry.", file=sys.stderr)
        return 3

    if len(raw) > MAX_HTML_BYTES:
        print(f"Source HTML exceeded the {MAX_HTML_BYTES}-byte safety limit.", file=sys.stderr)
        return 4

    try:
        html = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        print(f"Source HTML was not UTF-8: {exc}", file=sys.stderr)
        return 5

    lower = html.lower()
    if "<!doctype html" not in lower or "</html>" not in lower or "ai bale" not in lower:
        print(f"Unexpected response from {final_url}; refusing to package it as the app UI.", file=sys.stderr)
        return 6
    if "__allbatnativebridgeinstalled" in lower:
        print("Source already contains an injected bridge; refusing to double-inject.", file=sys.stderr)
        return 7

    audit_remote_content(html)

    bridge = BRIDGE.read_text(encoding="utf-8")
    injection = "\n<!-- All Bat Android native bridge; bundled at build time. -->\n<script>\n" + bridge + "\n</script>\n"
    if "__fbwidget" not in lower:
        widget = load_feedback_widget().replace("</script", "<\\/script")
        injection += "<!-- Voting (thumbs up/down) widget, same as the Space serves. -->\n<script>\n" + widget + "\n</script>\n"
    match = re.search(r"</body\s*>", html, flags=re.IGNORECASE)
    if match:
        html = html[:match.start()] + injection + html[match.start():]
    else:
        match = re.search(r"</html\s*>", html, flags=re.IGNORECASE)
        if not match:
            print("The source HTML has no closing body/html tag.", file=sys.stderr)
            return 8
        html = html[:match.start()] + injection + html[match.start():]

    ASSET_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(html, encoding="utf-8", newline="")
    print(f"Prepared {OUTPUT.relative_to(ROOT)} ({len(html.encode('utf-8'))} bytes)")
    print(f"Source: {final_url}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
